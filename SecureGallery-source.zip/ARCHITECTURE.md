# SecureGallery — System Architecture & Security Design

**Package:** `com.hamza.securegallery` · **Language:** Kotlin · **UI:** Jetpack Compose
**Min SDK 28 / Target SDK 35** · **Offline-first, zero network permissions**

This document is the design contract for the implementation in `app/src`.
Sections 1–5 are written *before* implementation, as required.

---

## 1. System Architecture

### 1.1 Layer diagram

```
┌─────────────────────────────────────────────────────────────┐
│ UI LAYER (Compose) — FLAG_SECURE on every sensitive screen  │
│ LockScreen · PinSetup · Gallery · Viewer · Albums · Settings │
│ ImportSheet · ExportDialog (explicit consent)                │
├─────────────────────────────────────────────────────────────┤
│ SESSION LAYER                                                │
│ AuthManager (PIN verify, rate limit, lock state, session DEK) │
│ AutoLockManager (lifecycle + screen-off + inactivity timer)  │
│ BiometricGate (BiometricPrompt → auth-bound unwrap)          │
├─────────────────────────────────────────────────────────────┤
│ DATA LAYER                                                   │
│ VaultRepository → VaultDatabase (SQLCipher, encrypted)       │
│ MediaImporter (PhotoPicker → streaming AES-GCM → vault)      │
│ ThumbnailCache (in-memory LruCache only, cleared on lock)    │
│ AesGcmDataSource (decrypt-on-the-fly stream for ExoPlayer)   │
├─────────────────────────────────────────────────────────────┤
│ CRYPTO LAYER                                                 │
│ CryptoManager: AES-256-GCM streaming file encryption         │
│ KeyManager:   Android Keystore master key → wraps vault DEK  │
│ SecureWipe:   overwrite-then-delete, buffer zeroization      │
├─────────────────────────────────────────────────────────────┤
│ ANDROID PLATFORM                                              │
│ App-private internal storage  getFilesDir()/vault/           │
│ Android Keystore (hardware-backed when available)            │
└─────────────────────────────────────────────────────────────┘
```

### 1.2 Storage architecture — keys separated from data

| Item | Where it lives | Protection |
|---|---|---|
| Encrypted media files | `getFilesDir()/vault/media/<uuid>.enc` | AES-256-GCM, per-file random 96-bit nonce, nonce prepended |
| Vault DEK (data encryption key, AES-256) | Wrapped blob in EncryptedSharedPreferences (`vault_prefs`) | Wrapped by Keystore master key (AES-256-GCM, Keystore-bound) |
| Master key | Android Keystore, alias `sg_master_v1` | Hardware-backed if device supports it; never leaves Keystore |
| Biometric wrap key (optional) | Android Keystore, alias `sg_bio_wrap_v1` | `setUserAuthenticationRequired(true)` — unwrap requires biometric |
| PIN verifier | EncryptedSharedPreferences | PBKDF2-HMAC-SHA256, 310 000 iterations, 128-bit salt; **verifier only, never the PIN** |
| Media metadata DB | `getFilesDir()/vault/meta.db` (SQLCipher) | Passphrase = HKDF-SHA256(DEK, "sg-meta-db-v1"); zeroized after open |
| Rate-limit counters | EncryptedSharedPreferences | Backoff state, failed-attempt count |
| Thumbnails / previews | **Memory only** (`LruCache<Bitmap>`) | Evicted + recycled on lock; never written to disk |
| Temp export files | `getCacheDir()/export/` | Deleted + overwritten immediately after share intent returns; export requires explicit user confirmation |

**What never exists:** plaintext media anywhere on disk, plaintext keys, plaintext PINs,
unencrypted thumbnails, MediaStore entries, `FileProvider` shares without explicit
one-shot URI grants, cloud backups of vault data (`allowBackup=false`).

### 1.3 Data flow — import

```
PhotoPicker (system UI, no storage permission)
  → content:// URI (read-only grant, this process only)
  → MediaImporter: validate MIME + sniff magic bytes (reject path traversal,
     reject non-image/video, cap size at 4 GB)
  → CryptoManager.encryptStream: read URI → AES-GCM → vault file (streaming, 64 KB chunks)
  → metadata row inserted into SQLCipher DB (original name, mime, size, dims, album)
  → source URI permission released; nothing retained outside vault
```

### 1.4 Data flow — view

```
AuthManager.unlock (PIN or biometric) → DEK held in memory only
  → Gallery queries SQLCipher DB → ThumbnailCache decrypts bytes → Bitmap in RAM
  → Viewer: image via in-memory Bitmap; video via AesGcmDataSource → ExoPlayer
  → on lock: DEK zeroized, DB closed, cache evicted, player released
```

### 1.5 Data flow — export (explicit consent only)

```
User taps Export → confirm dialog (names the file, warns it leaves the vault)
  → decrypt to getCacheDir()/export/<random>.tmp
  → ACTION_SEND with FileProvider URI + FLAG_GRANT_READ_URI_PERMISSION (one-shot)
  → onActivityResult / onDestroy: SecureWipe file, delete
```

---

## 2. Threat Model

### 2.1 In scope — mitigated by design

| # | Threat | Mitigation |
|---|---|---|
| T1 | Another app (different UID) reads vault files | Linux UID sandbox + `MODE_PRIVATE` internal storage; no `ContentProvider`, no exported components, no world-readable files |
| T2 | File manager / USB MTP sees media | Files live in app-private dir (invisible to MTP/MediaStore); payloads are AES-GCM ciphertext anyway |
| T3 | Media appears in system gallery / Recents | No `MediaStore` insertions, no `MediaScannerConnection.scanFile`, `.nomedia` belt-and-braces, `FLAG_SECURE` blocks Recents thumbnails |
| T4 | Screenshot / screen recording of viewer | `FLAG_SECURE` on all sensitive activities; viewer additionally blocks on rooted detection? No — honest: FLAG_SECURE only |
| T5 | Stolen locked device, offline brute force | DEK wrapped by Keystore key; PIN verifier is PBKDF2/310k; rate limiting + backoff; optional biometric-gated wrap key; no key material extractable without Keystore |
| T6 | Backup / restore leakage | `allowBackup="false"`, `fullBackupOnly="false"`, `dataExtractionRules` excluding everything; Auto Backup & key/value backup both off |
| T7 | Thumbnail / cache / log leakage | Memory-only thumbnails; no disk cache (image pipeline configured with disk cache disabled); logs stripped in release (`isMinifyEnabled`, no PII in log tags); crash reports contain no filenames |
| T8 | Malicious import (path traversal, polyglot, huge file) | MIME allowlist + magic-byte sniffing; filename never used for paths (UUID names); 4 GB cap; streaming (no full-file RAM load); ExifInterface only on in-memory bytes |
| T9 | Exported component / intent hijack | Every component `android:exported="false"` except launcher activity; no intent filters on sensitive activities; no implicit intents carry secrets |
| T10 | PIN guessing | Exponential backoff (2ⁿ s, cap 5 min), attempt counter persisted; optional auto-wipe after 10 failures (OFF by default, explicit warning) |
| T11 | Background / app-switcher exposure | Auto-lock on `ON_STOP` (configurable delay), `FLAG_SECURE` hides Recents preview, lock on `ACTION_SCREEN_OFF` |
| T12 | Tampered ciphertext | AES-GCM authentication tag — any modification fails closed with `AEADBadTagException`; no silent corruption |

### 2.2 Explicitly NOT preventable — honest limitations

| # | Threat | Why it can't be fully stopped |
|---|---|---|
| L1 | Rooted device / attacker with root | Root can read app-private files **and** Keystore keys (software Keystore) or use them via the Keystore daemon; hardware-backed keys raise the bar (rate-limited, non-exportable) but a compromised kernel still wins |
| L2 | Attacker controlling an **unlocked** device | Once the user unlocks the vault, DEK is in process memory; a debugger, runtime instrumentation (Frida), or malicious accessibility service can scrape it |
| L3 | Compromised OS / malicious ROM | All bets off — key attestation can *detect* some cases but not prevent |
| L4 | Guaranteed physical erasure of deleted files | Flash wear-leveling + FTL remapping mean overwritten blocks may survive in spare areas; we overwrite-then-delete (best effort) and document it |
| L5 | Cold-boot / RAM forensics on unlocked device | Session DEK lives in RAM while unlocked; auto-lock minimizes the window |
| L6 | Camera-based capture of the screen | FLAG_SECURE stops OS screenshots, not a second phone's camera |
| L7 | Forgetting PIN **and** losing biometric | By design there is no backdoor: the DEK cannot be recovered. Recovery = restore from the user's own encrypted export (documented at setup). This is stated plainly in onboarding |

**No fake security:** there is no "military-grade impossible to hack" claim anywhere in
the app or docs. The README's limitations section repeats L1–L7 verbatim.

---

## 3. Encryption & Key-Management Design

### 3.1 Algorithms (all platform-standard, no custom crypto)

- **File encryption:** AES-256-GCM (`AES/GCM/NoPadding`), 96-bit random nonce per file,
  128-bit auth tag. Streaming via `CipherOutputStream` / `CipherInputStream`.
- **Key wrapping:** Keystore AES-256-GCM key (`sg_master_v1`) wraps the DEK.
  KeyGenParameterSpec: `PURPOSE_ENCRYPT | PURPOSE_DECRYPT`, `BLOCK_MODE_GCM`,
  `ENCRYPTION_PADDING_NONE`, `setRandomizedEncryptionRequired(true)`,
  `setUserAuthenticationRequired(false)`, `setIsStrongBoxBacked(true)` with
  software fallback if StrongBox is absent.
- **Biometric gate:** separate Keystore key (`sg_bio_wrap_v1`) with
  `setUserAuthenticationRequired(true)` (+ `setUserAuthenticationParameters(0, AUTH_BIOMETRIC_STRONG)`
  on API 30+). It wraps a *copy* of the DEK; unwrapping requires a fresh biometric.
  Biometric is an alternative unlock path, never a bypass of the PIN (PIN remains enrolled).
- **PIN verification:** PBKDF2-HMAC-SHA256, 310 000 iterations, per-vault 128-bit salt,
  256-bit derived verifier. PIN collected as `CharArray`, zeroized after use.
  Minimum PIN length 6 (setup enforces; recommends 8+).
- **Metadata DB key:** `HKDF-SHA256(DEK, salt=random-16B, info="sg-meta-db-v1")` → 256-bit
  SQLCipher passphrase. DB file header is SQLCipher-encrypted; no plaintext schema leaks.
- **RNG:** `SecureRandom` (Android's `SHA1PRNG`-free default) for nonces, salts, DEK, UUIDs.

### 3.2 Key lifecycle

```
First launch (onboarding)
  1. User sets PIN (≥6 chars)
  2. KeyManager.ensureMasterKey() → generates sg_master_v1 in Keystore
  3. DEK = 256-bit SecureRandom  → wrapDek() → stored in EncryptedSharedPreferences
  4. PBKDF2(PIN, salt) verifier stored; PIN zeroized
  5. SQLCipher DB created with derived passphrase

Unlock
  PIN path:      verify PBKDF2 → unwrap DEK via master key → DEK in RAM (session)
  Biometric path: BiometricPrompt(CryptoObject: bio_wrap DECRYPT) → unwrap bio-wrapped
                  DEK copy → DEK in RAM (session)

Lock (background / timeout / manual / screen-off)
  → zeroize DEK bytes → close SQLCipher → evict thumbnail cache → release player
  → navigate to LockScreen → FLAG_SECURE already active

PIN change: verify old → re-derive verifier with NEW salt (DEK unchanged — no re-encryption)
Biometric enroll/disable: (re)wrap DEK copy under bio key / delete bio key
```

### 3.3 What the Keystore does and doesn't do

- Keys are **non-exportable**; crypto ops happen inside Keystore (TEE/StrongBox).
- On a locked device with a secure lock screen, Keystore keys are unavailable to
  background extraction — this is the main defense for T5.
- If the device has no TEE/StrongBox, keys fall back to software Keystore: still
  non-exportable via API, but weaker against root (documented, surfaced in
  Settings → Security as "Hardware security: TEE / StrongBox / Software").

---

## 4. Database Schema (SQLCipher — file itself encrypted)

```sql
-- vault_meta.db  (SQLCipher, passphrase derived from DEK per session)

CREATE TABLE albums (
    id          TEXT PRIMARY KEY,          -- UUID v4
    name        TEXT NOT NULL,             -- plaintext inside encrypted DB
    created_at  INTEGER NOT NULL,          -- epoch millis
    sort_order  INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE media (
    id          TEXT PRIMARY KEY,          -- UUID v4
    album_id    TEXT NOT NULL REFERENCES albums(id) ON DELETE CASCADE,
    vault_name  TEXT NOT NULL UNIQUE,      -- "<uuid>.enc", never the original name
    orig_name   TEXT NOT NULL,             -- original filename (encrypted at rest: whole DB is)
    mime        TEXT NOT NULL,             -- validated against allowlist on import
    size_bytes  INTEGER NOT NULL,
    width       INTEGER,                   -- image dims; NULL for video
    height      INTEGER,
    duration_ms INTEGER,                   -- video; NULL for image
    added_at    INTEGER NOT NULL,
    starred     INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_media_album ON media(album_id, added_at DESC);

CREATE TABLE kv (                  -- tiny encrypted key/value (settings that must
    k TEXT PRIMARY KEY,            -- survive reinstall-independent of prefs)
    v TEXT NOT NULL
);
-- kv keys: schema_version, auto_lock_timeout_ms, biometric_enabled,
--          wipe_after_failures_enabled, theme
```

Notes:
- No full-text index over filenames (search is a simple `LIKE` over the encrypted DB —
  the DB file is ciphertext on disk, so this leaks nothing at rest).
- `vault_name` is random; original names never touch the filesystem.
- Deleting a row → file is overwritten then deleted (`SecureWipe`).

---

## 5. Project Structure

```
secure-gallery/
├── ARCHITECTURE.md
├── SECURITY_TESTING_PLAN.md
├── README.md
├── settings.gradle.kts
├── build.gradle.kts                  (root)
├── gradle.properties
├── gradle/libs.versions.toml
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/
        ├── main/
        │   ├── AndroidManifest.xml    (allowBackup=false, no exported comps, no perms)
        │   └── java/com/hamza/securegallery/
        │       ├── SecureGalleryApp.kt        (Application; AutoLock init)
        │       ├── security/
        │       │   ├── KeyManager.kt           (Keystore master + bio keys, wrap/unwrap)
        │       │   ├── CryptoManager.kt        (AES-GCM streaming file crypto, HKDF)
        │       │   └── SecureWipe.kt           (overwrite+delete, zeroize)
        │       ├── auth/
        │       │   ├── AuthManager.kt           (PIN setup/verify, PBKDF2, rate limit, session DEK)
        │       │   └── BiometricGate.kt        (BiometricPrompt + CryptoObject)
        │       ├── data/
        │       │   ├── VaultDatabase.kt        (SQLCipher open helper)
        │       │   ├── VaultRepository.kt      (CRUD over encrypted DB)
        │       │   └── SecurePreferences.kt    (EncryptedSharedPreferences wrapper)
        │       ├── media/
        │       │   ├── MediaImporter.kt        (PhotoPicker import → encrypted vault)
        │       │   ├── ThumbnailCache.kt       (in-memory LruCache<Bitmap>)
        │       │   └── AesGcmDataSource.kt     (decrypting DataSource for ExoPlayer)
        │       ├── lock/
        │       │   └── AutoLockManager.kt      (lifecycle/screen-off/inactivity → lock)
        │       └── ui/
        │           ├── MainActivity.kt         (single activity, FLAG_SECURE)
        │           ├── Nav.kt                  (Compose navigation)
        │           └── screens/
        │               ├── OnboardingScreen.kt (PIN setup + honest recovery warning)
        │               ├── LockScreen.kt       (PIN pad + biometric button + backoff UI)
        │               ├── GalleryScreen.kt    (grid, in-memory thumbs, search/sort)
        │               ├── ViewerScreen.kt     (image / ExoPlayer video, FLAG_SECURE)
        │               ├── AlbumsScreen.kt     (album CRUD)
        │               ├── ImportScreen.kt     (PhotoPicker launcher, progress)
        │               └── SettingsScreen.kt   (auto-lock, biometric, wipe toggle, security info)
        ├── test/java/...                     (unit: crypto roundtrip, tamper, rate limit)
        └── androidTest/java/...              (manifest/exported check, backup off,
                                               MediaStore absence, vault isolation)
```

---

## 6. Build stages (how this was implemented)

1. **Stage 1 — Crypto & keys:** `KeyManager`, `CryptoManager`, `SecureWipe` + unit tests.
2. **Stage 2 — Auth & lock:** `AuthManager`, `BiometricGate`, `AutoLockManager`.
3. **Stage 3 — Vault data:** `VaultDatabase` (SQLCipher), `VaultRepository`, `MediaImporter`.
4. **Stage 4 — UI:** onboarding → lock → gallery → viewer → albums → settings.
5. **Stage 5 — Hardening & tests:** manifest lockdown, ProGuard, instrumented security tests,
   `SECURITY_TESTING_PLAN.md` execution notes.

## 7. Honest summary of guarantees

- At rest (locked): media is AES-256-GCM ciphertext under a DEK that is itself
  Keystore-wrapped; metadata is SQLCipher ciphertext. File managers, MTP, other apps,
  and backups see nothing usable.
- In use (unlocked): standard Android process/memory protections apply; a compromised
  OS, root, or debugger on the *unlocked* device can extract the session DEK (L1/L2).
- Forgotten credentials: unrecoverable by design (L7) — stated during onboarding, not
  buried in fine print.
