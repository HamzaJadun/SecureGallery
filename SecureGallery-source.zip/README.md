# SecureGallery — Ultra-Secure Private Gallery for Android

AES-256-GCM encrypted vault, Android Keystore key management, PIN + biometric
unlock, auto-lock, zero network permissions, zero storage permissions.
See [ARCHITECTURE.md](ARCHITECTURE.md) for the full design and threat model,
and [SECURITY_TESTING_PLAN.md](SECURITY_TESTING_PLAN.md) for verification.

## Project layout

Standard Gradle project (`:app` module). All source under
`app/src/main/java/com/hamza/securegallery/`. Unit tests in `app/src/test`,
instrumented security tests in `app/src/androidTest`.

## Prerequisites

- **Android Studio** Ladybug or newer (AGP 8.5.2, Kotlin 2.0.21)
- **JDK 17**
- Android SDK: Platform 35, Build-Tools 35, one emulator or device (API 28+;
  API 30+ recommended for the strongest biometric binding)
- A real device is recommended for Keystore hardware-backing tests
  (emulators use the software Keystore)

## Build

```bash
# 1. Open this folder in Android Studio and let it sync Gradle.
# 2. Or from the terminal (needs ANDROID_HOME / ANDROID_SDK_ROOT set).
#    If `gradlew` isn't present yet, open the project in Android Studio once —
#    it generates the Gradle wrapper — then:
./gradlew assembleDebug          # debug APK
./gradlew assembleRelease         # release APK (see signing below)
./gradlew testDebugUnitTest       # host-side unit tests (crypto, rate limit)
./gradlew connectedDebugAndroidTest   # on-device security tests
```

> This project was authored off-device, so the very first Gradle sync in
> Android Studio is the compile check. Dependency versions are pinned in
> `gradle/libs.versions.toml`; if a version has been superseded, bump it to
> the latest stable of the same artifact.

## Release signing (required before publishing)

1. Generate a keystore (keep it and its passwords **out of git**):
   `keytool -genkeypair -keystore securegallery.jks -alias sg -keyalg RSA -keysize 4096 -validity 9125`
2. Add to `local.properties` (never commit this file):
   ```
   sg.storeFile=/absolute/path/securegallery.jks
   sg.storePassword=…
   sg.keyAlias=sg
   sg.keyPassword=…
   ```
3. Add a `signingConfigs` block in `app/build.gradle.kts` reading those
   properties and assign it to the `release` build type.

## First run

1. Install, open, create a 6+ digit PIN. Read the recovery warning — it is
   honest: **a forgotten PIN cannot be recovered by anyone.**
2. Tap `+` → system photo picker → select photos/videos → they are
   AES-GCM-encrypted into the vault (originals untouched).
3. Settings → enable biometric unlock, tune auto-lock, inspect the
   security-status card.

## What the app deliberately does NOT do

- No internet permission → it cannot exfiltrate anything, even if compromised.
- No `READ_MEDIA_*` / storage permissions → import goes through the system
  Photo Picker with one-shot URI grants.
- No cloud backup of any kind (`allowBackup=false` + `dataExtractionRules`).
- No analytics, crash reporting, or logging of filenames/secrets.
- No share/print/cast except one explicit Export flow with a confirm dialog,
  a one-shot `FileProvider` grant, and immediate secure-wipe of the temp file.

## Honest limitations (also in ARCHITECTURE.md §2.2)

Root, a compromised OS, runtime instrumentation on an *unlocked* device, or a
second camera pointed at the screen can defeat any app-level protection —
this one included. Deleted-file erasure on flash storage is best-effort
(wear-leveling). The app never claims otherwise.
