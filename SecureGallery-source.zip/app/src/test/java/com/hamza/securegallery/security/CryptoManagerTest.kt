package com.hamza.securegallery.security

import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import javax.crypto.AEADBadTagException

/**
 * Pure-JVM tests for the crypto core. These run on the host (no device needed)
 * and verify the properties the threat model depends on:
 *  - round-trip correctness (bytes and streams)
 *  - tamper evidence (any bit flip fails closed)
 *  - nonce uniqueness (same plaintext -> different ciphertext)
 *  - HKDF determinism + domain separation
 */
class CryptoManagerTest {

    private val crypto = CryptoManager()

    @Test fun `encrypt-decrypt bytes round trip`() {
        val dek = crypto.generateDek()
        val plain = "hello vault".toByteArray()
        val blob = crypto.encryptBytes(dek, plain)
        assertArrayEquals(plain, crypto.decryptBytes(dek, blob))
        // Nonce prepended: blob is longer than plaintext + tag.
        assertTrue(blob.size > plain.size + 16)
    }

    @Test fun `encrypt-decrypt stream round trip`() {
        val dek = crypto.generateDek()
        val plain = ByteArray(300_000) { (it % 251).toByte() }
        val enc = ByteArrayOutputStream()
        crypto.encryptStream(dek, ByteArrayInputStream(plain), enc)
        val dec = ByteArrayOutputStream()
        crypto.decryptStream(dek, ByteArrayInputStream(enc.toByteArray()), dec)
        assertArrayEquals(plain, dec.toByteArray())
    }

    @Test fun `tampered ciphertext fails closed`() {
        val dek = crypto.generateDek()
        val blob = crypto.encryptBytes(dek, "secret".toByteArray())
        // Flip a bit in the ciphertext region (after the 12-byte nonce).
        blob[20] = (blob[20].toInt() xor 0x01).toByte()
        try {
            crypto.decryptBytes(dek, blob)
            fail("tampered blob must not decrypt")
        } catch (expected: AEADBadTagException) {
            // expected: authentication tag mismatch
        }
    }

    @Test fun `tampered nonce fails closed`() {
        val dek = crypto.generateDek()
        val blob = crypto.encryptBytes(dek, "secret".toByteArray())
        blob[3] = (blob[3].toInt() xor 0xFF).toByte()
        try {
            crypto.decryptBytes(dek, blob)
            fail("tampered nonce must not decrypt")
        } catch (expected: AEADBadTagException) {
        }
    }

    @Test fun `wrong key fails closed`() {
        val blob = crypto.encryptBytes(crypto.generateDek(), "secret".toByteArray())
        try {
            crypto.decryptBytes(crypto.generateDek(), blob)
            fail("wrong DEK must not decrypt")
        } catch (expected: AEADBadTagException) {
        }
    }

    @Test fun `same plaintext produces different ciphertext (random nonce)`() {
        val dek = crypto.generateDek()
        val a = crypto.encryptBytes(dek, "same".toByteArray())
        val b = crypto.encryptBytes(dek, "same".toByteArray())
        assertFalse(a.contentEquals(b))
    }

    @Test fun `truncated file is rejected`() {
        val dek = crypto.generateDek()
        try {
            crypto.decryptStream(
                dek,
                ByteArrayInputStream(ByteArray(5)),
                ByteArrayOutputStream()
            )
            fail("truncated file must be rejected")
        } catch (expected: IllegalArgumentException) {
        }
    }

    @Test fun `hkdf is deterministic and domain-separated`() {
        val dek = crypto.generateDek()
        val salt = ByteArray(16) { 7 }
        val k1 = crypto.hkdfSha256(dek, salt, "sg-meta-db-v1".toByteArray())
        val k2 = crypto.hkdfSha256(dek, salt, "sg-meta-db-v1".toByteArray())
        val k3 = crypto.hkdfSha256(dek, salt, "other-info".toByteArray())
        assertArrayEquals(k1, k2)
        assertFalse(k1.contentEquals(k3))
        assertEquals(32, k1.size)
    }

    @Test fun `zeroize clears buffers`() {
        val b = byteArrayOf(1, 2, 3, 4)
        crypto.zeroize(b)
        assertArrayEquals(ByteArray(4), b)
    }
}
