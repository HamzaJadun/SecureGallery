package com.hamza.securegallery.auth

import org.junit.Assert.*
import org.junit.Test

/**
 * Verifies the documented rate-limit schedule: 1s, 2s, 4s, 8s … capped at 5 min.
 * (Full PIN-verify integration is covered by instrumented tests on a device,
 * where the Android Keystore exists.)
 */
class AuthRateLimitTest {

    @Test fun `backoff doubles per failure`() {
        assertEquals(1_000L, AuthManager.backoffMs(1))
        assertEquals(2_000L, AuthManager.backoffMs(2))
        assertEquals(4_000L, AuthManager.backoffMs(3))
        assertEquals(8_000L, AuthManager.backoffMs(4))
    }

    @Test fun `backoff caps at five minutes`() {
        assertEquals(AuthManager.MAX_BACKOFF_MS, AuthManager.backoffMs(10))
        assertEquals(AuthManager.MAX_BACKOFF_MS, AuthManager.backoffMs(30))
        assertEquals(AuthManager.MAX_BACKOFF_MS, AuthManager.backoffMs(100))
    }

    @Test fun `wipe threshold is ten`() {
        assertEquals(10, AuthManager.WIPE_THRESHOLD)
    }

    @Test fun `pin minimum length is six`() {
        assertEquals(6, AuthManager.MIN_PIN_LEN)
    }
}
