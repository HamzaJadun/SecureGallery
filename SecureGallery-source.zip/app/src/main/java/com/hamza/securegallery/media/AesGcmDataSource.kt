package com.hamza.securegallery.media

import androidx.media3.common.C
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSpec
import com.hamza.securegallery.data.VaultRepository
import com.hamza.securegallery.security.CryptoManager
import java.io.EOFException
import java.io.FileInputStream
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * ExoPlayer DataSource that decrypts AES-256-GCM vault files on the fly.
 *
 * Videos are never written to disk decrypted: bytes flow
 * vault file → GCM decrypt → ExoPlayer, in 64 KB chunks.
 *
 * Limitation: GCM is not seekable without re-decrypting from the start, so
 * seeking re-opens the stream and skips forward (correct but O(n) per seek).
 * Documented tradeoff for authenticated encryption without temp files.
 */
class AesGcmDataSource(
    private val repo: VaultRepository,
    private val crypto: CryptoManager,
    private val dek: ByteArray
) : BaseDataSource(/* isNetwork = */ false) {

    private var stream: CipherInputStream? = null
    private var opened = false

    override fun open(dataSpec: DataSpec): Long {
        transferInitializing(dataSpec)
        val mediaId = (dataSpec.key ?: throw IllegalArgumentException("no media key"))
            .removePrefix("sg://")
        val item = repo.getMedia(mediaId)
            ?: throw java.io.FileNotFoundException("media not found")
        val file = repo.fileFor(item.vaultName)
        val fis = FileInputStream(file)
        try {
            val nonce = ByteArray(CryptoManager.NONCE_BYTES)
            var read = 0
            while (read < nonce.size) {
                val r = fis.read(nonce, read, nonce.size - read)
                if (r < 0) throw EOFException("truncated vault file")
                read += r
            }
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(
                Cipher.DECRYPT_MODE,
                SecretKeySpec(dek, "AES"),
                GCMParameterSpec(CryptoManager.TAG_BITS, nonce)
            )
            var s: CipherInputStream = CipherInputStream(fis, cipher)
            // GCM can't seek: skip by re-reading from the start.
            var toSkip = dataSpec.position
            val buf = ByteArray(64 * 1024)
            while (toSkip > 0) {
                val r = s.read(buf, 0, minOf(buf.size.toLong(), toSkip).toInt())
                if (r < 0) break
                toSkip -= r
            }
            stream = s
            opened = true
        } catch (t: Throwable) {
            try { fis.close() } catch (_: Exception) { }
            throw t
        }
        transferStarted(dataSpec)
        // Length unknown without decrypting fully; report unbounded.
        return C.LENGTH_UNSET.toLong()
    }

    override fun read(buffer: ByteArray, offset: Int, readLength: Int): Int {
        if (readLength == 0) return 0
        val s = stream ?: return C.RESULT_END_OF_INPUT
        val r = s.read(buffer, offset, readLength)
        if (r < 0) return C.RESULT_END_OF_INPUT
        bytesTransferred(r)
        return r
    }

    override fun getUri(): android.net.Uri? = null

    override fun close() {
        try { stream?.close() } catch (_: Exception) { }
        stream = null
        if (opened) {
            opened = false
            transferEnded()
        }
    }
}
