package com.hamza.securegallery.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.hamza.securegallery.SecureGalleryApp
import com.hamza.securegallery.data.Album
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Album management. Album names live inside the encrypted DB, so organizing
 * never leaks anything. Deleting an album moves its media to "All Photos"
 * rather than destroying user files.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlbumsScreen(app: SecureGalleryApp, onBack: () -> Unit, onPoke: () -> Unit) {
    val scope = rememberCoroutineScope()
    var albums by remember { mutableStateOf<List<Album>>(emptyList()) }
    var counts by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
    var showCreate by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<Album?>(null) }
    var deleteTarget by remember { mutableStateOf<Album?>(null) }
    var nameField by remember { mutableStateOf("") }

    fun refresh() {
        scope.launch(Dispatchers.IO) {
            val als = app.repo.listAlbums()
            val c = als.associate { it.id to app.repo.listMedia(it.id).size }
            withContext(Dispatchers.Main) { albums = als; counts = c }
        }
    }
    LaunchedEffect(Unit) { refresh() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Albums") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "Back") }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { onPoke(); nameField = ""; showCreate = true }) {
                Icon(Icons.Filled.Add, "New album")
            }
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize()) {
            items(albums, key = { it.id }) { album ->
                ListItem(
                    headlineContent = { Text(album.name) },
                    supportingContent = {
                        Text("${counts[album.id] ?: 0} item(s)")
                    },
                    trailingContent = {
                        Row {
                            if (album.id != "default") {
                                IconButton(onClick = {
                                    onPoke(); nameField = album.name; renameTarget = album
                                }) { Icon(Icons.Filled.Edit, "Rename") }
                                IconButton(onClick = { onPoke(); deleteTarget = album }) {
                                    Icon(Icons.Filled.Delete, "Delete")
                                }
                            }
                        }
                    },
                    modifier = Modifier.clickable { onPoke(); onBack() }
                )
            }
        }
    }

    if (showCreate) {
        AlbumDialog(
            title = "New album", initial = "",
            onDismiss = { showCreate = false },
            onConfirm = { name ->
                scope.launch(Dispatchers.IO) {
                    app.repo.createAlbum(name)
                    withContext(Dispatchers.Main) { showCreate = false; refresh() }
                }
            }
        )
    }
    renameTarget?.let { album ->
        AlbumDialog(
            title = "Rename album", initial = album.name,
            onDismiss = { renameTarget = null },
            onConfirm = { name ->
                scope.launch(Dispatchers.IO) {
                    app.repo.renameAlbum(album.id, name)
                    withContext(Dispatchers.Main) { renameTarget = null; refresh() }
                }
            }
        )
    }
    deleteTarget?.let { album ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete album?") },
            text = { Text("“${album.name}” will be removed; its photos move to All Photos. No files are deleted.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch(Dispatchers.IO) {
                        app.repo.deleteAlbum(album.id)
                        withContext(Dispatchers.Main) { deleteTarget = null; refresh() }
                    }
                }) { Text("Delete album") }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun AlbumDialog(
    title: String,
    initial: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var name by remember(initial) { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(60) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { if (name.isNotBlank()) onConfirm(name.trim()) },
                enabled = name.isNotBlank()
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
