package com.hamza.securegallery.data

import android.content.ContentValues
import android.content.Context
import com.hamza.securegallery.security.SecureWipe
import net.sqlcipher.database.SQLiteDatabase
import java.io.File
import java.util.UUID

data class Album(val id: String, val name: String, val createdAt: Long)
data class MediaItem(
    val id: String,
    val albumId: String,
    val vaultName: String,
    val origName: String,
    val mime: String,
    val sizeBytes: Long,
    val width: Int?,
    val height: Int?,
    val durationMs: Long?,
    val addedAt: Long,
    val starred: Boolean
) {
    val isVideo: Boolean get() = mime.startsWith("video/")
}

/**
 * CRUD over the encrypted metadata DB + the encrypted files on disk.
 * Every mutating op keeps DB and files in sync; files are always addressed by
 * random vault names, never by user-controlled paths (no traversal possible).
 */
class VaultRepository(private val context: Context) {

    @Volatile private var db: VaultDatabase? = null

    /** Call after unlock, with HKDF-derived passphrase bytes (zeroized by callee chain). */
    fun open(passphrase: ByteArray) {
        close()
        db = VaultDatabase.open(context, passphrase)
    }

    fun isOpen(): Boolean = db != null

    fun close() {
        try { db?.close() } catch (_: Exception) { }
        db = null
    }

    private fun db(): SQLiteDatabase =
        db?.openWritable() ?: throw IllegalStateException("Vault is locked")

    fun mediaDir(): File = File(context.filesDir, "vault/media").apply { mkdirs() }
    fun fileFor(vaultName: String): File {
        // Defense in depth: reject anything that isn't our generated name shape.
        require(vaultName.matches(Regex("[0-9a-f\\-]{36}\\.enc"))) { "Bad vault name" }
        return File(mediaDir(), vaultName)
    }

    // ---------- albums ----------

    fun listAlbums(): List<Album> {
        val out = mutableListOf<Album>()
        db().rawQuery(
            "SELECT id,name,created_at FROM albums ORDER BY sort_order, created_at", null
        ).use { c ->
            while (c.moveToNext()) {
                out += Album(c.getString(0), c.getString(1), c.getLong(2))
            }
        }
        return out
    }

    fun createAlbum(name: String): Album {
        val clean = name.trim().take(60).ifEmpty { "Untitled" }
        val album = Album(UUID.randomUUID().toString(), clean, System.currentTimeMillis())
        val cv = ContentValues().apply {
            put("id", album.id); put("name", album.name); put("created_at", album.createdAt)
        }
        db().insertOrThrow("albums", null, cv)
        return album
    }

    fun renameAlbum(id: String, name: String) {
        val cv = ContentValues().apply { put("name", name.trim().take(60)) }
        db().update("albums", cv, "id=? AND id!='default'", arrayOf(id))
    }

    fun deleteAlbum(id: String) {
        require(id != "default") { "Cannot delete the default album" }
        db().beginTransaction()
        try {
            // Move its media to default album instead of deleting user files.
            val cv = ContentValues().apply { put("album_id", "default") }
            db().update("media", cv, "album_id=?", arrayOf(id))
            db().delete("albums", "id=?", arrayOf(id))
            db().setTransactionSuccessful()
        } finally {
            db().endTransaction()
        }
    }

    // ---------- media ----------

    fun insertMedia(item: MediaItem) {
        val cv = ContentValues().apply {
            put("id", item.id); put("album_id", item.albumId)
            put("vault_name", item.vaultName); put("orig_name", item.origName)
            put("mime", item.mime); put("size_bytes", item.sizeBytes)
            item.width?.let { put("width", it) }; item.height?.let { put("height", it) }
            item.durationMs?.let { put("duration_ms", it) }
            put("added_at", item.addedAt); put("starred", if (item.starred) 1 else 0)
        }
        db().insertOrThrow("media", null, cv)
    }

    fun listMedia(albumId: String? = null, starredOnly: Boolean = false): List<MediaItem> {
        val where = StringBuilder("1=1")
        val args = mutableListOf<String>()
        if (albumId != null && albumId != "all") {
            where.append(" AND album_id=?"); args += albumId
        }
        if (starredOnly) where.append(" AND starred=1")
        val out = mutableListOf<MediaItem>()
        db().rawQuery(
            "SELECT id,album_id,vault_name,orig_name,mime,size_bytes,width,height," +
                "duration_ms,added_at,starred FROM media WHERE $where ORDER BY added_at DESC",
            args.toTypedArray()
        ).use { c ->
            while (c.moveToNext()) {
                out += MediaItem(
                    c.getString(0), c.getString(1), c.getString(2), c.getString(3),
                    c.getString(4), c.getLong(5),
                    if (c.isNull(6)) null else c.getInt(6),
                    if (c.isNull(7)) null else c.getInt(7),
                    if (c.isNull(8)) null else c.getLong(8),
                    c.getLong(9), c.getInt(10) == 1
                )
            }
        }
        return out
    }

    fun searchMedia(query: String): List<MediaItem> {
        val q = "%${query.trim().take(40)}%"
        val out = mutableListOf<MediaItem>()
        db().rawQuery(
            "SELECT id,album_id,vault_name,orig_name,mime,size_bytes,width,height," +
                "duration_ms,added_at,starred FROM media WHERE orig_name LIKE ? " +
                "ORDER BY added_at DESC",
            arrayOf(q)
        ).use { c ->
            while (c.moveToNext()) {
                out += MediaItem(
                    c.getString(0), c.getString(1), c.getString(2), c.getString(3),
                    c.getString(4), c.getLong(5),
                    if (c.isNull(6)) null else c.getInt(6),
                    if (c.isNull(7)) null else c.getInt(7),
                    if (c.isNull(8)) null else c.getLong(8),
                    c.getLong(9), c.getInt(10) == 1
                )
            }
        }
        return out
    }

    fun getMedia(id: String): MediaItem? {
        db().rawQuery(
            "SELECT id,album_id,vault_name,orig_name,mime,size_bytes,width,height," +
                "duration_ms,added_at,starred FROM media WHERE id=?",
            arrayOf(id)
        ).use { c ->
            if (!c.moveToFirst()) return null
            return MediaItem(
                c.getString(0), c.getString(1), c.getString(2), c.getString(3),
                c.getString(4), c.getLong(5),
                if (c.isNull(6)) null else c.getInt(6),
                if (c.isNull(7)) null else c.getInt(7),
                if (c.isNull(8)) null else c.getLong(8),
                c.getLong(9), c.getInt(10) == 1
            )
        }
    }

    fun setStarred(id: String, starred: Boolean) {
        val cv = ContentValues().apply { put("starred", if (starred) 1 else 0) }
        db().update("media", cv, "id=?", arrayOf(id))
    }

    fun moveToAlbum(id: String, albumId: String) {
        val cv = ContentValues().apply { put("album_id", albumId) }
        db().update("media", cv, "id=?", arrayOf(id))
    }

    /** Secure delete: overwrite + delete the ciphertext file, then drop the row. */
    fun deleteMedia(id: String): Boolean {
        val item = getMedia(id) ?: return false
        db().beginTransaction()
        return try {
            SecureWipe.wipeFile(fileFor(item.vaultName))
            db().delete("media", "id=?", arrayOf(id))
            db().setTransactionSuccessful()
            true
        } finally {
            db().endTransaction()
        }
    }

    fun countMedia(): Int {
        db().rawQuery("SELECT COUNT(*) FROM media", null).use { c ->
            return if (c.moveToFirst()) c.getInt(0) else 0
        }
    }

    fun totalBytes(): Long {
        db().rawQuery("SELECT COALESCE(SUM(size_bytes),0) FROM media", null).use { c ->
            return if (c.moveToFirst()) c.getLong(0) else 0L
        }
    }

    // ---------- settings kv ----------

    fun getSetting(key: String, def: String? = null): String? {
        db().rawQuery("SELECT v FROM kv WHERE k=?", arrayOf(key)).use { c ->
            return if (c.moveToFirst()) c.getString(0) else def
        }
    }

    fun setSetting(key: String, value: String) {
        val cv = ContentValues().apply { put("k", key); put("v", value) }
        db().insertWithOnConflict("kv", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }
}
