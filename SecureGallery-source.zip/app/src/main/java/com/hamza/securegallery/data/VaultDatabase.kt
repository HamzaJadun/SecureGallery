package com.hamza.securegallery.data

import android.content.Context
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SQLiteOpenHelper

/**
 * SQLCipher-encrypted metadata database at getFilesDir()/vault/vault_meta.db.
 * The file on disk is ciphertext; the passphrase is HKDF(DEK) derived fresh at
 * each unlock and zeroized right after the DB is opened.
 *
 * Schema v1:
 *   albums(id TEXT PK, name TEXT, created_at INT, sort_order INT)
 *   media(id TEXT PK, album_id TEXT, vault_name TEXT UNIQUE, orig_name TEXT,
 *         mime TEXT, size_bytes INT, width INT NULL, height INT NULL,
 *         duration_ms INT NULL, added_at INT, starred INT)
 *   kv(k TEXT PK, v TEXT)
 *
 * Known limitation (R-3 in SECURITY_TESTING_PLAN.md): SQLCipher's API takes the
 * passphrase as a String, so short-lived String copies exist in heap until GC.
 * The source byte[] is zeroized immediately after open.
 */
class VaultDatabase private constructor(
    context: Context,
    dbPath: String
) : SQLiteOpenHelper(context, dbPath, null, SCHEMA_VERSION) {

    companion object {
        const val SCHEMA_VERSION = 1
        private const val DB_REL = "vault/vault_meta.db"

        /**
         * Opens (creating on first run). Validates the passphrase immediately so a
         * wrong key fails fast instead of surfacing later. Zeroizes [passphrase]
         * before returning.
         */
        fun open(context: Context, passphrase: ByteArray): VaultDatabase {
            SQLiteDatabase.loadLibs(context)
            val dbFile = java.io.File(context.filesDir, DB_REL)
            dbFile.parentFile?.mkdirs()
            val helper = VaultDatabase(context.applicationContext, dbFile.absolutePath)
            val pwChars = passphrase.toPassphraseChars()
            try {
                helper.setPassphrase(pwChars.concatToString())
                helper.openWritable().close() // validates key now
            } finally {
                pwChars.fill('\u0000')
                CryptoZeroize(passphrase)
            }
            return helper
        }

        private fun ByteArray.toPassphraseChars(): CharArray =
            CharArray(size) { this[it].toInt().and(0xFF).toChar() }

        private fun CryptoZeroize(a: ByteArray) = a.fill(0)
    }

    @Volatile private var passphrase: String? = null
    private fun setPassphrase(pw: String) { passphrase = pw }

    /** Opens the encrypted database for writing using the stored passphrase. */
    fun openWritable(): SQLiteDatabase =
        super.getWritableDatabase(passphrase ?: throw IllegalStateException("DB not unlocked"))

    /** Opens the encrypted database for reading using the stored passphrase. */
    fun openReadable(): SQLiteDatabase =
        super.getReadableDatabase(passphrase ?: throw IllegalStateException("DB not unlocked"))

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE albums(
                id TEXT PRIMARY KEY, name TEXT NOT NULL,
                created_at INTEGER NOT NULL, sort_order INTEGER NOT NULL DEFAULT 0)"""
        )
        db.execSQL(
            """CREATE TABLE media(
                id TEXT PRIMARY KEY,
                album_id TEXT NOT NULL REFERENCES albums(id) ON DELETE CASCADE,
                vault_name TEXT NOT NULL UNIQUE, orig_name TEXT NOT NULL,
                mime TEXT NOT NULL, size_bytes INTEGER NOT NULL,
                width INTEGER, height INTEGER, duration_ms INTEGER,
                added_at INTEGER NOT NULL, starred INTEGER NOT NULL DEFAULT 0)"""
        )
        db.execSQL("CREATE INDEX idx_media_album ON media(album_id, added_at DESC)")
        db.execSQL("CREATE TABLE kv(k TEXT PRIMARY KEY, v TEXT NOT NULL)")
        db.execSQL(
            "INSERT INTO albums(id,name,created_at,sort_order) VALUES('default','All Photos',?,0)",
            arrayOf(System.currentTimeMillis())
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // v1 — no migrations yet. Add ALTER TABLE steps here for future versions.
    }

    override fun close() {
        try { super.close() } catch (_: Exception) { }
        passphrase = null
    }
}
