package com.hamza.securegallery.ui.screens

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AssistChip
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import com.hamza.securegallery.SecureGalleryApp
import com.hamza.securegallery.data.Album
import com.hamza.securegallery.data.MediaItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Encrypted gallery grid. Thumbnails are decrypted on demand into RAM only
 * (ThumbnailCache) — the grid never touches disk plaintext.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GalleryScreen(
    app: SecureGalleryApp,
    onOpen: (String) -> Unit,
    onAlbums: () -> Unit,
    onSettings: () -> Unit,
    onLock: () -> Unit,
    onPoke: () -> Unit
) {
    val dek = app.authManager.sessionDek()
    if (dek == null) {
        // Shouldn't happen: lock events navigate away. Render nothing.
        Box(Modifier.fillMaxSize()); return
    }
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    var items by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var albums by remember { mutableStateOf<List<Album>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var albumFilter by remember { mutableStateOf("all") }
    var starredOnly by remember { mutableStateOf(false) }
    var importing by remember { mutableStateOf(false) }

    fun refresh() {
        scope.launch(Dispatchers.IO) {
            val list = if (query.isBlank()) {
                app.repo.listMedia(albumFilter.ifEmpty { "all" }, starredOnly)
            } else {
                app.repo.searchMedia(query)
            }
            val als = app.repo.listAlbums()
            withContext(Dispatchers.Main) {
                items = list; albums = als
            }
        }
    }
    LaunchedEffect(query, albumFilter, starredOnly) { refresh() }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(maxItems = 20)
    ) { uris ->
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        importing = true
        scope.launch(Dispatchers.IO) {
            val target = if (albumFilter == "all" || albumFilter.isEmpty()) "default" else albumFilter
            val res = app.importer.importUris(uris, target, dek)
            withContext(Dispatchers.Main) {
                importing = false
                refresh()
                scope.launch {
                    val msg = if (res.skipped.isEmpty()) {
                        "Imported ${res.imported} item(s). Originals untouched."
                    } else {
                        "Imported ${res.imported}; skipped ${res.skipped.size} (unsupported)."
                    }
                    snackbar.showSnackbar(msg)
                }
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text("Vault") },
                actions = {
                    IconButton(onClick = { onPoke(); onAlbums() }) {
                        Icon(Icons.Filled.Folder, "Albums")
                    }
                    IconButton(onClick = { onPoke(); onSettings() }) {
                        Icon(Icons.Filled.Settings, "Settings")
                    }
                    IconButton(onClick = { onLock() }) {
                        Icon(Icons.Filled.Lock, "Lock now")
                    }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it; onPoke() },
                placeholder = { Text("Search by filename") },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                singleLine = true
            )
            Row(
                modifier = Modifier.padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AssistChip(
                    onClick = { albumFilter = "all"; onPoke() },
                    label = { Text("All") },
                    leadingIcon = null
                )
                AssistChip(
                    onClick = { starredOnly = !starredOnly; onPoke() },
                    label = { Text("Starred") },
                    leadingIcon = { Icon(Icons.Filled.Star, null) }
                )
            }
            if (importing) {
                Row(
                    Modifier.fillMaxWidth().padding(8.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(Modifier.padding(end = 8.dp))
                    Text("Encrypting & importing…")
                }
            }
            if (items.isEmpty() && !importing) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Vault is empty", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Tap + to import via the system picker.\nFiles are encrypted before they land in the vault.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    contentPadding = PaddingValues(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(items, key = { it.id }) { item ->
                        VaultThumb(app, dek, item, onClick = { onPoke(); onOpen(item.id) })
                    }
                }
            }
            // Import FAB row
            Row(
                Modifier.fillMaxWidth().padding(12.dp),
                horizontalArrangement = Arrangement.End
            ) {
                androidx.compose.material3.FloatingActionButton(
                    onClick = {
                        onPoke()
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                    }
                ) { Icon(Icons.Filled.Add, "Import") }
            }
            Spacer(Modifier.height(4.dp))
        }
    }
}

@Composable
private fun VaultThumb(
    app: SecureGalleryApp,
    dek: ByteArray,
    item: MediaItem,
    onClick: () -> Unit
) {
    var bmp by remember(item.id) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(item.id) {
        bmp = withContext(Dispatchers.IO) {
            try { app.thumbCache.get(item, dek, 256) } catch (_: Exception) { null }
        }
    }
    Box(
        modifier = Modifier
            .aspectRatio(1f)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(
                b.asImageBitmap(), contentDescription = null,
                modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop
            )
        } else if (item.isVideo) {
            Icon(Icons.Filled.PlayArrow, "Video", tint = Color.White,
                modifier = Modifier.padding(24.dp))
        }
        if (item.starred) {
            Icon(
                Icons.Filled.Star, "Starred",
                tint = Color.Yellow,
                modifier = Modifier.align(Alignment.TopEnd).padding(4.dp)
            )
        }
    }
}
