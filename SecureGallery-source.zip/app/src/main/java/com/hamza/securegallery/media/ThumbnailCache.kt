package com.hamza.securegallery.media

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import com.hamza.securegallery.data.MediaItem
import com.hamza.securegallery.data.VaultRepository
import com.hamza.securegallery.security.CryptoManager
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * In-memory thumbnail cache — the ONLY place thumbnails exist.
 *
 * - Decrypts the vault file into a bounded RAM buffer (8 MB cap; enough for
 *   header + a downsampled decode), decodes a downsampled Bitmap, caches it.
 * - NEVER writes thumbnails, previews, or any plaintext to disk.
 * - [clear] is called on every lock: bitmaps are recycled and the cache
 *   evicted, so nothing sensitive survives in the process after locking.
 */
class ThumbnailCache(
    private val repo: VaultRepository,
    private val crypto: CryptoManager,
    maxEntries: Int = 120
) {
    private val cache = object : LruCache<String, Bitmap>(maxEntries) {
        override fun entryRemoved(evicted: Boolean, key: String, old: Bitmap, new: Bitmap?) {
            if (evicted || old != new) {
                try { if (!old.isRecycled) old.recycle() } catch (_: Exception) { }
            }
        }
    }

    @Synchronized
    fun get(item: MediaItem, dek: ByteArray, targetPx: Int = 256): Bitmap? {
        cache.get(item.id)?.let { return it }
        val bmp = decodeThumb(item, dek, targetPx) ?: return null
        cache.put(item.id, bmp)
        return bmp
    }

    @Synchronized
    fun clear() {
        for (i in 0 until cache.size()) { /* entryRemoved handles recycle on evict */ }
        cache.evictAll()
    }

    private fun decodeThumb(item: MediaItem, dek: ByteArray, targetPx: Int): Bitmap? {
        return try {
            val file: File = repo.fileFor(item.vaultName)
            val plain = ByteArrayOutputStream()
            // Cap: thumbnails don't need the whole multi-GB video in RAM.
            val cap = 8 * 1024 * 1024
            file.inputStream().use { fis ->
                val capped = CappedInput(fis, (CryptoManager.NONCE_BYTES + cap).toLong())
                try {
                    crypto.decryptStream(dek, capped, plain)
                } catch (_: Exception) {
                    // Truncated tag expected when capped; header bytes are enough.
                }
            }
            val bytes = plain.toByteArray()
            if (bytes.isEmpty()) return null

            if (item.isVideo) {
                // First frame: decode bounds only — full frame extraction would need
                // MediaMetadataRetriever on plaintext; instead show a generic tile.
                // (Honest tradeoff: no video frame thumbs without a plaintext temp file,
                // which we refuse to create.)
                return null
            }
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            if (bounds.outWidth <= 0) return null
            var sample = 1
            while (bounds.outWidth / sample > targetPx || bounds.outHeight / sample > targetPx) {
                sample *= 2
            }
            val opts = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.RGB_565 // half the RAM of ARGB_8888
            }
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
            bytes.fill(0)
            bmp
        } catch (_: Exception) {
            null
        }
    }

    private class CappedInput(
        inner: java.io.InputStream,
        private var left: Long
    ) : java.io.FilterInputStream(inner) {
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (left <= 0) return -1
            val r = super.read(b, off, minOf(len.toLong(), left).toInt())
            if (r > 0) left -= r
            return r
        }
        override fun read(): Int {
            if (left <= 0) return -1
            val b = super.read()
            if (b >= 0) left--
            return b
        }
    }
}
