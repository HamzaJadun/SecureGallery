package com.hamza.securegallery.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import com.hamza.securegallery.SecureGalleryApp
import com.hamza.securegallery.auth.AuthManager
import kotlinx.coroutines.delay

/**
 * Unlock screen: PIN pad + optional biometric button.
 * Failed attempts show the enforced wait (exponential backoff); the input is
 * disabled during the lockout window. Attempt counts never reveal whether a
 * vault exists beyond this device (it always does post-onboarding).
 */
@Composable
fun LockScreen(app: SecureGalleryApp, activity: FragmentActivity, onUnlocked: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var waitMs by remember { mutableStateOf(0L) }
    var bioMsg by remember { mutableStateOf<String?>(null) }

    // Tick down the lockout window.
    LaunchedEffect(waitMs) {
        while (waitMs > 0) {
            delay(1000)
            waitMs = (waitMs - 1000).coerceAtLeast(0)
        }
    }

    fun tryUnlock() {
        if (pin.length < AuthManager.MIN_PIN_LEN || waitMs > 0) return
        when (val r = app.authManager.verifyPin(pin.toCharArray())) {
            is AuthManager.AuthResult.Success -> {
                pin = ""
                message = null
                onUnlocked()
            }
            is AuthManager.AuthResult.Failure -> {
                pin = ""
                waitMs = r.waitMs
                message = if (r.waitMs > 0) {
                    "Wrong PIN. Wait ${r.waitMs / 1000}s before retrying."
                } else {
                    "Wrong PIN. Try again."
                }
            }
            is AuthManager.AuthResult.LockedOut -> {
                pin = ""
                waitMs = r.waitMs
                message = "Too many attempts. Wait ${r.waitMs / 1000}s."
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(48.dp))
        Text("SecureGallery", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Vault is locked", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        bioMsg?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant) }

        PinPad(
            pin = pin,
            enabled = waitMs <= 0,
            onPinChange = { pin = it.filter { c -> c.isDigit() }; message = null },
            onSubmit = { tryUnlock() }
        )

        Button(
            onClick = { tryUnlock() },
            modifier = Modifier.fillMaxWidth(),
            enabled = pin.length >= AuthManager.MIN_PIN_LEN && waitMs <= 0
        ) { Text(if (waitMs > 0) "Wait ${waitMs / 1000}s" else "Unlock") }

        if (app.biometricGate.canUse()) {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = {
                    app.biometricGate.unlock(activity) { ok, msg ->
                        bioMsg = msg
                        if (ok) onUnlocked()
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Unlock with biometrics") }
        }
    }
}
