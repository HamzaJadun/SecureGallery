package com.hamza.securegallery.lock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import com.hamza.securegallery.SecureGalleryApp

/**
 * Auto-lock enforcement:
 * 1. App goes to background (ON_STOP) → lock after [timeoutMs] (default: immediate).
 * 2. Screen turns off → lock immediately (via ScreenOffReceiver).
 * 3. Inactivity timer resets on user interaction while unlocked.
 *
 * Locking = AuthManager.lock() + repo.close() + thumbnail cache clear +
 * player release + navigate to LockScreen. Implemented centrally in
 * SecureGalleryApp.lockNow(); this class only decides WHEN.
 */
class AutoLockManager(private val app: SecureGalleryApp) : DefaultLifecycleObserver {

    companion object {
        const val DEFAULT_TIMEOUT_MS = 0L // lock immediately on background
        val PRESETS_MS = listOf(0L, 60_000L, 300_000L, 900_000L)
    }

    var timeoutMs: Long = DEFAULT_TIMEOUT_MS

    private val handler = Handler(Looper.getMainLooper())
    private var lastInteraction = SystemClock.elapsedRealtime()
    private val lockRunnable = Runnable {
        if (app.authManager.isUnlocked &&
            SystemClock.elapsedRealtime() - lastInteraction >= timeoutMs
        ) {
            app.lockNow("inactivity")
        } else {
            schedule()
        }
    }

    fun start() {
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
        // SCREEN_OFF receiver is registered by SecureGalleryApp (dynamic registration
        // is required — manifest receivers don't get this broadcast on API 26+).
        schedule()
    }

    /** Call from UI on any meaningful user interaction. */
    fun poke() {
        lastInteraction = SystemClock.elapsedRealtime()
        schedule()
    }

    private fun schedule() {
        handler.removeCallbacks(lockRunnable)
        if (timeoutMs <= 0) return // background-lock handled by onStop path
        handler.postDelayed(lockRunnable, timeoutMs)
    }

    override fun onStop(owner: LifecycleOwner) {
        // App backgrounded: honor the timeout (0 = immediate).
        if (timeoutMs <= 0) {
            app.lockNow("background")
        } else {
            // Re-anchor the timer to "now" so background time counts.
            lastInteraction = SystemClock.elapsedRealtime()
            schedule()
        }
    }

    override fun onStart(owner: LifecycleOwner) {
        poke()
    }

    fun stop() {
        handler.removeCallbacks(lockRunnable)
        try {
            ProcessLifecycleOwner.get().lifecycle.removeObserver(this)
        } catch (_: Exception) { }
    }
}

/** Manifest-declared receiver: screen off always means lock now. */
class ScreenOffReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_SCREEN_OFF) {
            (context.applicationContext as? SecureGalleryApp)?.lockNow("screen_off")
        }
    }
}
