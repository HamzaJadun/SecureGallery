package com.hamza.securegallery.ui

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.fragment.app.FragmentActivity
import com.hamza.securegallery.SecureGalleryApp
import com.hamza.securegallery.ui.screens.AlbumsScreen
import com.hamza.securegallery.ui.screens.GalleryScreen
import com.hamza.securegallery.ui.screens.LockScreen
import com.hamza.securegallery.ui.screens.OnboardingScreen
import com.hamza.securegallery.ui.screens.SettingsScreen
import com.hamza.securegallery.ui.screens.ViewerScreen

/** App screens. Manual nav keeps the graph tiny and auditable. */
sealed interface Screen {
    data object Onboarding : Screen
    data object Lock : Screen
    data object Gallery : Screen
    data class Viewer(val mediaId: String) : Screen
    data object Albums : Screen
    data object Settings : Screen
}

class MainActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Block screenshots, screen recording, and Recents thumbnails on every
        // screen. This is set on the window, so it covers all Compose content.
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )

        val app = application as SecureGalleryApp
        setContent {
            SecureGalleryTheme {
                AppNav(app, this)
            }
        }

        // Safety net: any temp export left behind is wiped when the UI dies.
        // (Also wiped on every lock.)
    }

    override fun onDestroy() {
        try {
            (application as SecureGalleryApp).exportHelper.cleanup()
        } catch (_: Exception) { }
        super.onDestroy()
    }
}

@Composable
private fun SecureGalleryTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme() // respects system; Settings offers force-dark/light too
    MaterialTheme(
        colorScheme = if (dark) darkColorScheme() else lightColorScheme(),
        content = content
    )
}

@Composable
private fun AppNav(app: SecureGalleryApp, activity: FragmentActivity) {
    var screen by remember {
        mutableStateOf<Screen>(
            if (app.authManager.isEnrolled) Screen.Lock else Screen.Onboarding
        )
    }

    // Central lock events (background, screen-off, timeout, manual) → lock screen.
    val lockCount by app.lockEvents.collectAsState()
    LaunchedEffect(lockCount) {
        if (lockCount > 0) {
            screen = if (app.authManager.isEnrolled) Screen.Lock else Screen.Onboarding
        }
    }

    // Any tap counts as interaction for the inactivity timer.
    val poke = { app.autoLock.poke() }

    when (val s = screen) {
        is Screen.Onboarding -> OnboardingScreen(
            app = app,
            onDone = {
                val dek = app.authManager.sessionDek() ?: return@OnboardingScreen
                app.openVault(dek)
                screen = Screen.Gallery
            }
        )
        is Screen.Lock -> LockScreen(
            app = app,
            activity = activity,
            onUnlocked = {
                val dek = app.authManager.sessionDek() ?: return@LockScreen
                app.openVault(dek)
                screen = Screen.Gallery
            }
        )
        is Screen.Gallery -> GalleryScreen(
            app = app,
            onOpen = { id -> poke(); screen = Screen.Viewer(id) },
            onAlbums = { poke(); screen = Screen.Albums },
            onSettings = { poke(); screen = Screen.Settings },
            onLock = { app.lockNow("manual") },
            onPoke = poke
        )
        is Screen.Viewer -> ViewerScreen(
            app = app,
            activity = activity,
            mediaId = s.mediaId,
            onBack = { poke(); screen = Screen.Gallery },
            onPoke = poke
        )
        is Screen.Albums -> AlbumsScreen(
            app = app,
            onBack = { poke(); screen = Screen.Gallery },
            onPoke = poke
        )
        is Screen.Settings -> SettingsScreen(
            app = app,
            activity = activity,
            onBack = { poke(); screen = Screen.Gallery },
            onPoke = poke
        )
    }
}
