package com.hamza.securegallery

import android.app.Application
import android.content.IntentFilter
import android.content.Intent
import com.hamza.securegallery.auth.AuthManager
import com.hamza.securegallery.auth.BiometricGate
import com.hamza.securegallery.data.SecurePreferences
import com.hamza.securegallery.data.VaultRepository
import com.hamza.securegallery.lock.AutoLockManager
import com.hamza.securegallery.lock.ScreenOffReceiver
import com.hamza.securegallery.media.ExportHelper
import com.hamza.securegallery.media.MediaImporter
import com.hamza.securegallery.media.ThumbnailCache
import com.hamza.securegallery.security.CryptoManager
import com.hamza.securegallery.security.KeyManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Composition root + central lock authority.
 *
 * [lockNow] is the single choke point for locking: zeroizes the session DEK,
 * closes the encrypted DB, evicts in-memory thumbnails, and tells the UI to
 * show the lock screen. Nothing can read vault content after it returns.
 */
class SecureGalleryApp : Application() {

    lateinit var prefs: SecurePreferences; private set
    lateinit var keys: KeyManager; private set
    lateinit var crypto: CryptoManager; private set
    lateinit var authManager: AuthManager; private set
    lateinit var biometricGate: BiometricGate; private set
    lateinit var repo: VaultRepository; private set
    lateinit var importer: MediaImporter; private set
    lateinit var thumbCache: ThumbnailCache; private set
    lateinit var exportHelper: ExportHelper; private set
    lateinit var autoLock: AutoLockManager; private set

    private val _lockEvents = MutableStateFlow(0)
    /** Incremented on every lock; UI collects it to navigate to the lock screen. */
    val lockEvents: StateFlow<Int> = _lockEvents.asStateFlow()

    var lockReason: String = ""
        private set

    override fun onCreate() {
        installCrashReporter()
        super.onCreate()
        prefs = SecurePreferences(this)
        keys = KeyManager()
        crypto = CryptoManager()
        authManager = AuthManager(this, prefs, keys, crypto)
        biometricGate = BiometricGate(this, keys, crypto, prefs, authManager)
        repo = VaultRepository(this)
        importer = MediaImporter(this, repo, crypto)
        thumbCache = ThumbnailCache(repo, crypto)
        exportHelper = ExportHelper(this, repo, crypto)
        autoLock = AutoLockManager(this)
        autoLock.timeoutMs = prefs.getLong(
            SecurePreferences.Keys.AUTO_LOCK_MS, AutoLockManager.DEFAULT_TIMEOUT_MS
        )
        autoLock.start()
        registerReceiver(ScreenOffReceiver(), IntentFilter(Intent.ACTION_SCREEN_OFF))
    }

    /**
     * Diagnostic crash reporter: writes any uncaught exception's stack trace to
     * the Downloads folder as "securegallery-crash.txt" so it can be retrieved
     * without root/ADB. Temporary diagnostic aid.
     */
    private fun installCrashReporter() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, e ->
            try {
                val trace = android.util.Log.getStackTraceString(e) +
                    "\n\nDevice: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}" +
                    "\nAndroid SDK: ${android.os.Build.VERSION.SDK_INT}"
                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    val values = android.content.ContentValues().apply {
                        put(android.provider.MediaStore.Downloads.DISPLAY_NAME,
                            "securegallery-crash.txt")
                        put(android.provider.MediaStore.Downloads.MIME_TYPE, "text/plain")
                    }
                    val uri = contentResolver.insert(
                        android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    uri?.let {
                        contentResolver.openOutputStream(it)?.use { os ->
                            os.write(trace.toByteArray())
                        }
                    }
                } else {
                    @Suppress("DEPRECATION")
                    java.io.File(
                        android.os.Environment.getExternalStoragePublicDirectory(
                            android.os.Environment.DIRECTORY_DOWNLOADS),
                        "securegallery-crash.txt"
                    ).writeText(trace)
                }
            } catch (_: Exception) { }
            defaultHandler?.uncaughtException(thread, e)
        }
    }

    /**
     * Opens the encrypted metadata DB for this session. Must be called right
     * after a successful unlock, with the session DEK.
     */
    fun openVault(dek: ByteArray) {
        val salt = prefs.getBlob(SecurePreferences.Keys.DB_SALT)
            ?: throw IllegalStateException("DB salt missing")
        val dbKey = crypto.hkdfSha256(dek, salt, "sg-meta-db-v1".toByteArray())
        try {
            repo.open(dbKey)
        } finally {
            crypto.zeroize(dbKey)
        }
    }

    /** Irreversible-without-PIN lock. Safe to call when already locked. */
    fun lockNow(reason: String) {
        lockReason = reason
        if (authManager.isUnlocked || repo.isOpen()) {
            try { exportHelper.cleanup() } catch (_: Exception) { }
            try { thumbCache.clear() } catch (_: Exception) { }
            try { repo.close() } catch (_: Exception) { }
            authManager.lock() // zeroizes DEK last
        }
        // Always emit: after a wipe the vault is gone and the UI must route
        // to onboarding even though nothing was "unlocked".
        _lockEvents.value += 1
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        // Under memory pressure while unlocked, drop thumbnails (they re-decrypt on demand).
        if (authManager.isUnlocked) {
            try { thumbCache.clear() } catch (_: Exception) { }
        }
    }
}
