package com.hamza.securegallery.ui.screens

import android.graphics.BitmapFactory
import android.view.ViewGroup
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.fragment.app.FragmentActivity
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.datasource.DataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.PlayerView
import com.hamza.securegallery.SecureGalleryApp
import com.hamza.securegallery.data.MediaItem
import com.hamza.securegallery.media.AesGcmDataSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

/**
 * Secure viewer. Images: decrypted to RAM, downsampled to screen, shown.
 * Videos: ExoPlayer fed by AesGcmDataSource (decrypt-on-the-fly, no temp file).
 * No share/print/cast affordances except the explicit Export flow (confirm dialog).
 * Player + bitmaps are released when leaving; the inactivity timer keeps running.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ViewerScreen(
    app: SecureGalleryApp,
    activity: FragmentActivity,
    mediaId: String,
    onBack: () -> Unit,
    onPoke: () -> Unit
) {
    val dek = app.authManager.sessionDek()
    if (dek == null) { Box(Modifier.fillMaxSize()); return }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var item by remember(mediaId) { mutableStateOf<MediaItem?>(null) }
    var image by remember(mediaId) { mutableStateOf<android.graphics.Bitmap?>(null) }
    var loading by remember(mediaId) { mutableStateOf(true) }
    var error by remember(mediaId) { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    var confirmExport by remember { mutableStateOf(false) }

    LaunchedEffect(mediaId) {
        withContext(Dispatchers.IO) {
            val it = app.repo.getMedia(mediaId)
            withContext(Dispatchers.Main) { item = it }
            if (it == null) {
                withContext(Dispatchers.Main) {
                    error = "Item not found."; loading = false
                }
                return@withContext
            }
            if (!it.isVideo) {
                try {
                    val bmp = decryptImage(app, dek, it)
                    withContext(Dispatchers.Main) { image = bmp }
                } catch (t: Throwable) {
                    withContext(Dispatchers.Main) { error = "Couldn't decrypt image." }
                } finally {
                    withContext(Dispatchers.Main) { loading = false }
                }
            } else {
                withContext(Dispatchers.Main) { loading = false }
            }
        }
    }

    DisposableEffect(mediaId) {
        onDispose {
            image?.recycle()
            image = null
            try { app.exportHelper.cleanup() } catch (_: Exception) { }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(item?.origName ?: "", maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "Back") }
                },
                actions = {
                    item?.let { it ->
                        IconButton(onClick = {
                            onPoke()
                            scope.launch(Dispatchers.IO) {
                                app.repo.setStarred(it.id, !it.starred)
                                val fresh = app.repo.getMedia(it.id)
                                withContext(Dispatchers.Main) { item = fresh }
                            }
                        }) {
                            Icon(
                                if (it.starred) Icons.Filled.Star else Icons.Outlined.Star,
                                "Star"
                            )
                        }
                        IconButton(onClick = { onPoke(); confirmExport = true }) {
                            Icon(Icons.Filled.Share, "Export")
                        }
                        IconButton(onClick = { onPoke(); confirmDelete = true }) {
                            Icon(Icons.Filled.Delete, "Delete")
                        }
                    }
                }
            )
        }
    ) { pad ->
        Box(
            Modifier.padding(pad).fillMaxSize().background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            when {
                loading -> CircularProgressIndicator()
                error != null -> Text(error!!, color = Color.White)
                item?.isVideo == true -> VideoPlayer(app, dek, item!!)
                image != null -> Image(
                    image!!.asImageBitmap(), null,
                    modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit
                )
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete permanently?") },
            text = { Text("The encrypted file is overwritten and deleted. This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    scope.launch(Dispatchers.IO) {
                        app.repo.deleteMedia(mediaId)
                        withContext(Dispatchers.Main) { onBack() }
                    }
                }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }

    if (confirmExport) {
        val it = item
        AlertDialog(
            onDismissRequest = { confirmExport = false },
            title = { Text("Export this file?") },
            text = {
                Text(
                    "It will be decrypted and shared outside the vault to an app you choose. " +
                        "It will no longer be protected by SecureGallery."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmExport = false
                    if (it != null) {
                        scope.launch(Dispatchers.IO) {
                            try {
                                val uri = app.exportHelper.prepareExport(it, dek)
                                val share = app.exportHelper.shareIntent(uri, it.mime)
                                withContext(Dispatchers.Main) {
                                    context.startActivity(
                                        android.content.Intent.createChooser(share, "Export via")
                                    )
                                }
                            } catch (t: Throwable) {
                                app.exportHelper.cleanup()
                            }
                        }
                    }
                }) { Text("Export") }
            },
            dismissButton = { TextButton(onClick = { confirmExport = false }) { Text("Cancel") } }
        )
    }
}

/** Decrypts an image fully to RAM (bounded) and downsamples to ≤2048px. */
private fun decryptImage(
    app: SecureGalleryApp,
    dek: ByteArray,
    item: MediaItem
): android.graphics.Bitmap? {
    val out = ByteArrayOutputStream()
    app.repo.fileFor(item.vaultName).inputStream().use { fis ->
        // 100 MB sanity cap for a single image; larger files are rejected here
        // rather than OOMing the process.
        val capped = object : java.io.FilterInputStream(fis) {
            var left = 100L * 1024 * 1024
            override fun read(b: ByteArray, off: Int, len: Int): Int {
                if (left <= 0) throw IllegalArgumentException("image too large to display")
                val r = super.read(b, off, minOf(len.toLong(), left).toInt())
                if (r > 0) left -= r
                return r
            }
        }
        app.crypto.decryptStream(dek, capped, out)
    }
    val bytes = out.toByteArray()
    return try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / sample > 2048 || bounds.outHeight / sample > 2048) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    } finally {
        bytes.fill(0)
    }
}

@Composable
private fun VideoPlayer(app: SecureGalleryApp, dek: ByteArray, item: MediaItem) {
    val context = LocalContext.current
    val player = remember(item.id) {
        val factory = DataSource.Factory { AesGcmDataSource(app.repo, app.crypto, dek) }
        val source = ProgressiveMediaSource.Factory(factory)
            .createMediaSource(ExoMediaItem.fromUri("sg://${item.id}"))
        ExoPlayer.Builder(context).build().apply {
            setMediaSource(source)
            prepare()
        }
    }
    DisposableEffect(item.id) {
        onDispose { player.release() }
    }
    AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                this.player = player
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            }
        },
        modifier = Modifier.fillMaxSize()
    )
}
