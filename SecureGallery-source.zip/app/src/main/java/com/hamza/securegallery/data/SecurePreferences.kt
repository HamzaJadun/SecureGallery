package com.hamza.securegallery.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * All key-value state lives in EncryptedSharedPreferences (AES-256-GCM via
 * AndroidX Security). Contents: wrapped DEK, PIN verifier + salt, rate-limit
 * counters, settings flags. No plaintext secrets anywhere.
 */
class SecurePreferences(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "vault_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    // Raw blobs are Base64'd because SharedPreferences stores strings.
    fun putBlob(key: String, bytes: ByteArray) {
        prefs.edit().putString(
            key, android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
        ).apply()
    }

    fun getBlob(key: String): ByteArray? =
        prefs.getString(key, null)?.let {
            android.util.Base64.decode(it, android.util.Base64.NO_WRAP)
        }

    fun remove(key: String) = prefs.edit().remove(key).apply()

    fun putString(key: String, v: String) = prefs.edit().putString(key, v).apply()
    fun getString(key: String, def: String? = null): String? = prefs.getString(key, def)
    fun putLong(key: String, v: Long) = prefs.edit().putLong(key, v).apply()
    fun getLong(key: String, def: Long = 0L): Long = prefs.getLong(key, def)
    fun putInt(key: String, v: Int) = prefs.edit().putInt(key, v).apply()
    fun getInt(key: String, def: Int = 0): Int = prefs.getInt(key, def)
    fun putBoolean(key: String, v: Boolean) = prefs.edit().putBoolean(key, v).apply()
    fun getBoolean(key: String, def: Boolean = false): Boolean = prefs.getBoolean(key, def)
    fun contains(key: String): Boolean = prefs.contains(key)

    companion object Keys {
        const val WRAPPED_DEK = "wrapped_dek"          // Keystore-wrapped vault DEK
        const val WRAPPED_DEK_BIO = "wrapped_dek_bio"  // bio-gated copy (optional)
        const val PIN_VERIFIER = "pin_verifier_b64"
        const val PIN_SALT = "pin_salt_b64"
        const val FAIL_COUNT = "fail_count"
        const val LOCKOUT_UNTIL = "lockout_until_ms"
        const val BIO_ENABLED = "bio_enabled"
        const val AUTO_LOCK_MS = "auto_lock_ms"
        const val WIPE_AFTER_FAILURES = "wipe_after_failures"
        const val DB_SALT = "db_salt_b64"
    }
}
