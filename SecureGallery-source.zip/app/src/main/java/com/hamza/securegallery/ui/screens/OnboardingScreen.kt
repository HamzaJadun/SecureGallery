package com.hamza.securegallery.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hamza.securegallery.SecureGalleryApp
import com.hamza.securegallery.auth.AuthManager

/**
 * First-run: PIN setup with the honest recovery warning up front.
 * There is no backdoor by design — losing the PIN (and biometric, if enrolled)
 * means the vault cannot be recovered. This screen says so plainly.
 */
@Composable
fun OnboardingScreen(app: SecureGalleryApp, onDone: () -> Unit) {
    var stage by remember { mutableStateOf(0) } // 0 = enter, 1 = confirm
    var first by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(32.dp))
        Text("SecureGallery", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(
            "Your private, encrypted vault",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(24.dp))

        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
            Text(
                "Important: there is no password recovery.\n" +
                    "Your photos are encrypted with a key that only your PIN can unlock. " +
                    "If you forget your PIN, your vault cannot be recovered — not even by the developer. " +
                    "Choose a PIN you will remember.",
                modifier = Modifier.padding(16.dp),
                style = MaterialTheme.typography.bodySmall
            )
        }
        Spacer(Modifier.height(16.dp))
        Text(
            if (stage == 0) "Create a PIN (min ${AuthManager.MIN_PIN_LEN} digits)" else "Confirm your PIN",
            style = MaterialTheme.typography.titleMedium
        )
        error?.let {
            Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp))
        }

        PinPad(
            pin = pin,
            onPinChange = {
                pin = it.filter { c -> c.isDigit() }
                error = null
            }
        )

        Button(
            onClick = {
                if (pin.length < AuthManager.MIN_PIN_LEN) {
                    error = "PIN must be at least ${AuthManager.MIN_PIN_LEN} digits."
                    return@Button
                }
                if (stage == 0) {
                    first = pin; pin = ""; stage = 1
                } else {
                    if (pin != first) {
                        error = "PINs don't match. Try again."
                        pin = ""; first = ""; stage = 0
                        return@Button
                    }
                    try {
                        app.authManager.enroll(pin.toCharArray())
                        pin = ""; first = ""
                        onDone()
                    } catch (t: Throwable) {
                        error = t.message ?: "Setup failed."
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = pin.length >= AuthManager.MIN_PIN_LEN
        ) {
            Text(if (stage == 0) "Continue" else "Create vault")
        }
        Spacer(Modifier.height(12.dp))
        Text(
            "AES-256-GCM encryption · Keys in Android Keystore · No cloud backup · No analytics",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
