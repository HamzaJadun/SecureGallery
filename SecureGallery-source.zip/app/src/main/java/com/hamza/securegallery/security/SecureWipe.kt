package com.hamza.securegallery.security

import java.io.File
import java.io.RandomAccessFile
import java.security.SecureRandom

/**
 * Best-effort secure deletion.
 *
 * Honest limitation (see ARCHITECTURE.md L4): on flash storage, wear-leveling and
 * the FTL mean overwritten blocks can survive in spare areas. We still overwrite
 * with random data before deleting — it defeats file-carving of the logical file
 * and is the most a user-space app can do. We never claim physical erasure.
 */
object SecureWipe {
    private val rng = SecureRandom()
    private const val PASSES = 2
    private const val CHUNK = 64 * 1024

    /** Overwrites [file] with random data (2 passes) then deletes it. */
    fun wipeFile(file: File) {
        try {
            if (file.isFile && file.length() > 0) {
                RandomAccessFile(file, "rw").use { raf ->
                    val buf = ByteArray(CHUNK)
                    repeat(PASSES) {
                        raf.seek(0)
                        var remaining = raf.length()
                        while (remaining > 0) {
                            val n = minOf(CHUNK.toLong(), remaining).toInt()
                            rng.nextBytes(buf)
                            raf.write(buf, 0, n)
                            remaining -= n
                        }
                        raf.fd.sync()
                    }
                }
            }
        } catch (_: Exception) {
            // Best effort: even if overwrite fails, still attempt delete.
        } finally {
            try { file.delete() } catch (_: Exception) { }
        }
    }

    /** Wipes every file directly inside [dir] (non-recursive for safety) then the dir. */
    fun wipeDirContents(dir: File) {
        dir.listFiles()?.forEach { if (it.isFile) wipeFile(it) }
    }
}
