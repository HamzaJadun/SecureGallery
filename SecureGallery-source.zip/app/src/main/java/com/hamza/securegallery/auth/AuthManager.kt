package com.hamza.securegallery.auth

import android.content.Context
import android.os.SystemClock
import com.hamza.securegallery.data.SecurePreferences
import com.hamza.securegallery.security.CryptoManager
import com.hamza.securegallery.security.KeyManager
import com.hamza.securegallery.security.SecureWipe
import java.io.File
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * PIN lifecycle, verification with rate limiting, and session-DEK custody.
 *
 * Design rules enforced here:
 * - The PIN itself is NEVER stored. Only a PBKDF2-HMAC-SHA256 verifier
 *   (310k iterations, 128-bit salt) is kept, inside encrypted prefs.
 * - The vault DEK is unwrapped into RAM only after successful auth, and is
 *   zeroized on [lock]. There is no way to read vault files while locked.
 * - Rate limiting: exponential backoff 2^(n-1) seconds after each failure,
 *   capped at 5 minutes; counters persist across process death.
 * - Optional "wipe vault after 10 consecutive failures" — OFF by default and
 *   requires explicit opt-in with a warning (destructive).
 * - No hardcoded passwords, no bypass codes, no debug unlock.
 */
class AuthManager(
    private val context: Context,
    private val prefs: SecurePreferences,
    private val keys: KeyManager,
    private val crypto: CryptoManager
) {
    sealed interface AuthResult {
        data object Success : AuthResult
        /** Failure: must wait [waitMs] before the next attempt. */
        data class Failure(val waitMs: Long, val attemptsUsed: Int) : AuthResult
        /** Currently in a lockout window. */
        data class LockedOut(val waitMs: Long) : AuthResult
    }

    companion object {
        const val MIN_PIN_LEN = 6
        const val PBKDF2_ITERATIONS = 310_000
        private const val SALT_BYTES = 16
        private const val VERIFIER_BYTES = 32
        const val MAX_BACKOFF_MS = 5 * 60 * 1000L
        const val WIPE_THRESHOLD = 10
        private val rng = SecureRandom()

        /** Pure function so the backoff schedule is unit-testable. */
        internal fun backoffMs(failedAttempts: Int): Long {
            require(failedAttempts >= 1)
            return minOf((1L shl (failedAttempts - 1)) * 1000L, MAX_BACKOFF_MS)
        }
    }

    @Volatile private var sessionDek: ByteArray? = null

    val isEnrolled: Boolean get() = prefs.contains(SecurePreferences.Keys.PIN_VERIFIER)
    val isUnlocked: Boolean get() = sessionDek != null

    /** For internal use by repository/importer/viewer while unlocked. Null when locked. */
    fun sessionDek(): ByteArray? = sessionDek

    // ---------- enrollment ----------

    /** First-time setup. Throws on weak PIN. */
    fun enroll(pin: CharArray) {
        require(pin.size >= MIN_PIN_LEN) { "PIN must be at least $MIN_PIN_LEN characters" }
        keys.ensureMasterKey()
        val dek = crypto.generateDek()
        try {
            prefs.putBlob(SecurePreferences.Keys.WRAPPED_DEK, keys.wrapWithMaster(dek))
            val salt = ByteArray(SALT_BYTES).also { rng.nextBytes(it) }
            prefs.putBlob(SecurePreferences.Keys.PIN_SALT, salt)
            prefs.putBlob(SecurePreferences.Keys.PIN_VERIFIER, pbkdf2(pin, salt))
            // DB salt for HKDF-derived SQLCipher passphrase
            prefs.putBlob(
                SecurePreferences.Keys.DB_SALT,
                ByteArray(SALT_BYTES).also { rng.nextBytes(it) }
            )
            resetFailures()
            sessionDek = dek.copyOf()
        } finally {
            crypto.zeroize(dek)
            pin.fill('\u0000')
        }
    }

    /** Change PIN: verifies the old one, re-derives verifier with a FRESH salt. DEK unchanged. */
    fun changePin(oldPin: CharArray, newPin: CharArray): Boolean {
        require(newPin.size >= MIN_PIN_LEN) { "PIN must be at least $MIN_PIN_LEN characters" }
        val ok = when (val r = verifyPinInternal(oldPin, countFailure = false)) {
            is AuthResult.Success -> true
            else -> false
        }
        if (!ok) return false
        return try {
            val salt = ByteArray(SALT_BYTES).also { rng.nextBytes(it) }
            prefs.putBlob(SecurePreferences.Keys.PIN_SALT, salt)
            prefs.putBlob(SecurePreferences.Keys.PIN_VERIFIER, pbkdf2(newPin, salt))
            resetFailures()
            true
        } finally {
            newPin.fill('\u0000')
        }
    }

    // ---------- verification ----------

    fun verifyPin(pin: CharArray): AuthResult = verifyPinInternal(pin, countFailure = true)

    private fun verifyPinInternal(pin: CharArray, countFailure: Boolean): AuthResult {
        try {
            val now = SystemClock.elapsedRealtime()
            val lockoutUntil = prefs.getLong(SecurePreferences.Keys.LOCKOUT_UNTIL)
            if (now < lockoutUntil) return AuthResult.LockedOut(lockoutUntil - now)

            val salt = prefs.getBlob(SecurePreferences.Keys.PIN_SALT)
                ?: return AuthResult.Failure(0, 0)
            val expected = prefs.getBlob(SecurePreferences.Keys.PIN_VERIFIER)
                ?: return AuthResult.Failure(0, 0)

            val candidate = pbkdf2(pin, salt)
            val ok = constantTimeEquals(candidate, expected)
            crypto.zeroize(candidate)

            if (ok) {
                resetFailures()
                val wrapped = prefs.getBlob(SecurePreferences.Keys.WRAPPED_DEK)
                    ?: throw IllegalStateException("Vault DEK missing")
                sessionDek = keys.unwrapWithMaster(wrapped)
                return AuthResult.Success
            }

            if (countFailure) {
                val fails = prefs.getInt(SecurePreferences.Keys.FAIL_COUNT) + 1
                prefs.putInt(SecurePreferences.Keys.FAIL_COUNT, fails)
                if (prefs.getBoolean(SecurePreferences.Keys.WIPE_AFTER_FAILURES) &&
                    fails >= WIPE_THRESHOLD
                ) {
                    wipeVault()
                    return AuthResult.Failure(0, fails)
                }
                val waitMs = backoffMs(fails)
                prefs.putLong(SecurePreferences.Keys.LOCKOUT_UNTIL, now + waitMs)
                return AuthResult.Failure(waitMs, fails)
            }
            return AuthResult.Failure(0, prefs.getInt(SecurePreferences.Keys.FAIL_COUNT))
        } finally {
            pin.fill('\u0000')
        }
    }

    // ---------- biometric path ----------

    /**
     * Called after BiometricGate successfully unwraps the bio-gated DEK copy.
     * Establishes the session without the PIN (user explicitly enrolled this).
     */
    fun unlockWithDek(dek: ByteArray) {
        crypto.zeroize(sessionDek ?: ByteArray(0))
        sessionDek = dek.copyOf()
        resetFailures()
    }

    /** Enroll biometric: wraps current session DEK under the auth-bound bio key. */
    fun enrollBiometric(wrappedByBio: ByteArray) {
        check(isUnlocked) { "Must be unlocked to enroll biometric" }
        prefs.putBlob(SecurePreferences.Keys.WRAPPED_DEK_BIO, wrappedByBio)
        prefs.putBoolean(SecurePreferences.Keys.BIO_ENABLED, true)
    }

    fun disableBiometric() {
        keys.deleteBioWrapKey()
        prefs.remove(SecurePreferences.Keys.WRAPPED_DEK_BIO)
        prefs.putBoolean(SecurePreferences.Keys.BIO_ENABLED, false)
    }

    val isBiometricEnabled: Boolean
        get() = prefs.getBoolean(SecurePreferences.Keys.BIO_ENABLED) &&
            keys.hasBioWrapKey() &&
            prefs.contains(SecurePreferences.Keys.WRAPPED_DEK_BIO)

    // ---------- lock / wipe ----------

    /** Locks the vault: zeroizes DEK. Caller also closes DB + clears caches. */
    fun lock() {
        sessionDek?.let { crypto.zeroize(it) }
        sessionDek = null
    }

    /** Destructive: overwrites + deletes vault dir and clears all prefs. No recovery. */
    fun wipeVault() {
        lock()
        try {
            SecureWipe.wipeDirContents(File(context.filesDir, "vault"))
        } catch (_: Exception) { }
        // Clear encrypted prefs (best effort; file itself is encrypted at rest)
        listOf(
            SecurePreferences.Keys.WRAPPED_DEK, SecurePreferences.Keys.WRAPPED_DEK_BIO,
            SecurePreferences.Keys.PIN_VERIFIER, SecurePreferences.Keys.PIN_SALT,
            SecurePreferences.Keys.DB_SALT
        ).forEach { prefs.remove(it) }
        resetFailures()
    }

    // ---------- internals ----------

    private fun resetFailures() {
        prefs.putInt(SecurePreferences.Keys.FAIL_COUNT, 0)
        prefs.putLong(SecurePreferences.Keys.LOCKOUT_UNTIL, 0L)
    }

    private fun pbkdf2(pin: CharArray, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin, salt, PBKDF2_ITERATIONS, VERIFIER_BYTES * 8)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                .generateSecret(spec).encoded.also { spec.clearPassword() }
        } finally {
            spec.clearPassword()
        }
    }

    private fun constantTimeEquals(a: ByteArray, b: ByteArray): Boolean {
        if (a.size != b.size) return false
        var diff = 0
        for (i in a.indices) diff = diff or (a[i].toInt() xor b[i].toInt())
        return diff == 0
    }
}
