package com.hamza.securegallery.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import com.hamza.securegallery.SecureGalleryApp
import com.hamza.securegallery.auth.AuthManager
import com.hamza.securegallery.data.SecurePreferences
import com.hamza.securegallery.security.KeyManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Security settings. Every toggle here maps to a real mechanism:
 * auto-lock → AutoLockManager, biometric → Keystore auth-bound key,
 * wipe-after-failures → AuthManager counter. The "security status" card
 * reports the actual hardware backing instead of claiming more.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    app: SecureGalleryApp,
    activity: FragmentActivity,
    onBack: () -> Unit,
    onPoke: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var autoLockMs by remember {
        mutableStateOf(app.prefs.getLong(SecurePreferences.Keys.AUTO_LOCK_MS, 0L))
    }
    var bioEnabled by remember { mutableStateOf(app.authManager.isBiometricEnabled) }
    var wipeEnabled by remember {
        mutableStateOf(app.prefs.getBoolean(SecurePreferences.Keys.WIPE_AFTER_FAILURES))
    }
    var bioMsg by remember { mutableStateOf<String?>(null) }
    var showPinDialog by remember { mutableStateOf(false) }
    var showWipeConfirm by remember { mutableStateOf(false) }
    var stats by remember { mutableStateOf("…") }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            val n = app.repo.countMedia()
            val bytes = app.repo.totalBytes()
            withContext(Dispatchers.Main) {
                stats = "$n item(s) · ${"%.1f".format(bytes / 1024.0 / 1024.0)} MB encrypted"
            }
        }
    }

    val backing = remember {
        when (app.keys.hardwareBacking(activity.packageManager)) {
            KeyManager.HardwareBacking.STRONGBOX -> "StrongBox (dedicated security chip)"
            KeyManager.HardwareBacking.TEE -> "Trusted Execution Environment"
            KeyManager.HardwareBacking.SOFTWARE -> "Software Keystore (weaker — see docs)"
            KeyManager.HardwareBacking.UNKNOWN -> "Unknown"
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings & Security") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "Back") }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize()
                .verticalScroll(rememberScrollState()).padding(16.dp)
        ) {
            SectionTitle("Security status")
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(16.dp)) {
                    StatusRow("Vault", "Locked with AES-256-GCM · unlocked now")
                    StatusRow("Key storage", backing)
                    StatusRow("Backups", "Disabled (app + cloud + device transfer)")
                    StatusRow("Screenshots", "Blocked (FLAG_SECURE)")
                    StatusRow("Network", "No internet permission — fully offline")
                    StatusRow("Contents", stats)
                }
            }

            SectionTitle("Auto-lock")
            listOf(
                0L to "Immediately when app goes to background",
                60_000L to "After 1 minute",
                300_000L to "After 5 minutes",
                900_000L to "After 15 minutes"
            ).forEach { (ms, label) ->
                Row(
                    Modifier.fillMaxWidth().selectable(
                        selected = autoLockMs == ms,
                        onClick = {
                            onPoke()
                            autoLockMs = ms
                            app.prefs.putLong(SecurePreferences.Keys.AUTO_LOCK_MS, ms)
                            app.autoLock.timeoutMs = ms
                        },
                        role = Role.RadioButton
                    ).padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = autoLockMs == ms, onClick = null)
                    Text(label, Modifier.padding(start = 8.dp))
                }
            }
            Text(
                "Screen turning off always locks immediately.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            SectionTitle("Biometric unlock")
            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Use biometrics to unlock")
                    Text(
                        "Optional. Your PIN always still works.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    bioMsg?.let {
                        Text(it, style = MaterialTheme.typography.bodySmall)
                    }
                }
                Switch(
                    checked = bioEnabled,
                    onCheckedChange = { want ->
                        onPoke()
                        if (want) {
                            if (!app.keys.hasStrongBiometric(activity)) {
                                bioMsg = "No strong biometrics enrolled on this device."
                            } else {
                                app.biometricGate.enroll(activity) { ok, msg ->
                                    bioMsg = msg
                                    bioEnabled = ok && app.authManager.isBiometricEnabled
                                }
                            }
                        } else {
                            app.authManager.disableBiometric()
                            bioEnabled = false
                            bioMsg = "Biometric unlock disabled."
                        }
                    }
                )
            }

            SectionTitle("PIN")
            Button(onClick = { onPoke(); showPinDialog = true }) { Text("Change PIN") }

            SectionTitle("Failed attempts")
            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Wipe vault after 10 failed unlocks")
                    Text(
                        "Destructive and irreversible. Off by default.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
                Switch(
                    checked = wipeEnabled,
                    onCheckedChange = {
                        onPoke()
                        wipeEnabled = it
                        app.prefs.putBoolean(SecurePreferences.Keys.WIPE_AFTER_FAILURES, it)
                    }
                )
            }
            Text(
                "Without this, wrong PINs trigger an exponential wait (up to 5 minutes).",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            SectionTitle("Danger zone")
            Button(
                onClick = { onPoke(); showWipeConfirm = true },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
            ) { Text("Wipe vault permanently") }
            Text(
                "Overwrites and deletes every encrypted file and key. Cannot be undone.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showPinDialog) {
        var old by remember { mutableStateOf("") }
        var new1 by remember { mutableStateOf("") }
        var new2 by remember { mutableStateOf("") }
        var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { showPinDialog = false },
            title = { Text("Change PIN") },
            text = {
                Column {
                    err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                    OutlinedTextField(old, { old = it.filter { c -> c.isDigit() } },
                        label = { Text("Current PIN") }, singleLine = true)
                    OutlinedTextField(new1, { new1 = it.filter { c -> c.isDigit() } },
                        label = { Text("New PIN (min ${AuthManager.MIN_PIN_LEN})") }, singleLine = true)
                    OutlinedTextField(new2, { new2 = it.filter { c -> c.isDigit() } },
                        label = { Text("Confirm new PIN") }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch(Dispatchers.IO) {
                        val ok = try {
                            if (new1 != new2) {
                                withContext(Dispatchers.Main) { err = "New PINs don't match." }
                                return@launch
                            }
                            app.authManager.changePin(old.toCharArray(), new1.toCharArray())
                        } catch (t: Throwable) {
                            withContext(Dispatchers.Main) { err = t.message }
                            return@launch
                        } finally {
                            withContext(Dispatchers.Main) { old = "" }
                        }
                        withContext(Dispatchers.Main) {
                            if (ok) showPinDialog = false else err = "Current PIN is wrong."
                        }
                    }
                }) { Text("Change") }
            },
            dismissButton = { TextButton(onClick = { showPinDialog = false }) { Text("Cancel") } }
        )
    }

    if (showWipeConfirm) {
        var pin by remember { mutableStateOf("") }
        var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { showWipeConfirm = false },
            title = { Text("Wipe vault permanently?") },
            text = {
                Column {
                    Text("Every encrypted photo and video will be overwritten and deleted. There is no recovery.")
                    err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                    OutlinedTextField(pin, { pin = it.filter { c -> c.isDigit() } },
                        label = { Text("Enter PIN to confirm") }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch(Dispatchers.IO) {
                        val verified = try {
                            app.authManager.changePin(pin.toCharArray(), pin.toCharArray())
                        } catch (_: Throwable) { false }
                        // changePin with same PIN re-verifies without changing anything
                        // (new salt, same PIN) — used here as a verify gate.
                        if (verified) {
                            app.authManager.wipeVault()
                            withContext(Dispatchers.Main) {
                                showWipeConfirm = false
                                app.lockNow("wipe")
                            }
                        } else {
                            withContext(Dispatchers.Main) { err = "Wrong PIN." }
                        }
                    }
                }) { Text("Wipe everything", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { showWipeConfirm = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun SectionTitle(t: String) {
    Text(
        t, style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 20.dp, bottom = 8.dp)
    )
}

@Composable
private fun StatusRow(k: String, v: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text("$k: ", style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(v, style = MaterialTheme.typography.bodySmall)
    }
}
