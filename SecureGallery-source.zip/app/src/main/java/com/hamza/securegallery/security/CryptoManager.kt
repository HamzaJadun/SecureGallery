package com.hamza.securegallery.security

import java.io.InputStream
import java.io.OutputStream
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * AES-256-GCM file encryption plus key-derivation helpers.
 *
 * File format:  [12-byte nonce] [ciphertext + 16-byte GCM tag]
 * Every file gets a fresh random nonce. Tampering fails closed with
 * AEADBadTagException on decrypt — never silent corruption.
 *
 * All bulk work is streaming (64 KB chunks) so multi-GB videos never sit
 * fully in RAM.
 */
class CryptoManager {

    companion object {
        const val NONCE_BYTES = 12
        const val TAG_BITS = 128
        const val DEK_BYTES = 32 // AES-256
        private const val BUFFER = 64 * 1024
        private val RNG = SecureRandom()
    }

    fun generateDek(): ByteArray = randomBytes(DEK_BYTES)
    fun randomNonce(): ByteArray = randomBytes(NONCE_BYTES)
    private fun randomBytes(n: Int): ByteArray = ByteArray(n).also { RNG.nextBytes(it) }

    private fun aesKey(dek: ByteArray) = SecretKeySpec(dek, "AES")

    /** Encrypts [input] → [output], prepending the random nonce. */
    fun encryptStream(dek: ByteArray, input: InputStream, output: OutputStream) {
        val nonce = randomNonce()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, aesKey(dek), GCMParameterSpec(TAG_BITS, nonce))
        output.write(nonce)
        CipherOutputStream(output, cipher).use { cos ->
            input.copyTo(cos, BUFFER)
        }
    }

    /** Decrypts [input] (nonce-prefixed) → [output]. Throws AEADBadTagException if tampered. */
    fun decryptStream(dek: ByteArray, input: InputStream, output: OutputStream) {
        val nonce = ByteArray(NONCE_BYTES)
        var read = 0
        while (read < NONCE_BYTES) {
            val r = input.read(nonce, read, NONCE_BYTES - read)
            if (r < 0) throw IllegalArgumentException("Truncated vault file: missing nonce")
            read += r
        }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, aesKey(dek), GCMParameterSpec(TAG_BITS, nonce))
        CipherInputStream(input, cipher).use { cis ->
            cis.copyTo(output, BUFFER)
        }
    }

    fun encryptBytes(dek: ByteArray, plain: ByteArray): ByteArray {
        val nonce = randomNonce()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, aesKey(dek), GCMParameterSpec(TAG_BITS, nonce))
        return nonce + cipher.doFinal(plain)
    }

    fun decryptBytes(dek: ByteArray, blob: ByteArray): ByteArray {
        require(blob.size > NONCE_BYTES) { "Blob too short" }
        val nonce = blob.copyOfRange(0, NONCE_BYTES)
        val ct = blob.copyOfRange(NONCE_BYTES, blob.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, aesKey(dek), GCMParameterSpec(TAG_BITS, nonce))
        return cipher.doFinal(ct)
    }

    /**
     * HKDF-SHA256 (RFC 5869) extract-and-expand. Used to derive the SQLCipher
     * passphrase from the DEK so the raw DEK never doubles as a DB password.
     */
    fun hkdfSha256(ikm: ByteArray, salt: ByteArray, info: ByteArray, outLen: Int = 32): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        // Extract
        mac.init(SecretKeySpec(if (salt.isEmpty()) ByteArray(32) else salt, "HmacSHA256"))
        val prk = mac.doFinal(ikm)
        // Expand
        val okm = ByteArray(outLen)
        var prev = ByteArray(0)
        var pos = 0
        var counter = 1
        while (pos < outLen) {
            mac.init(SecretKeySpec(prk, "HmacSHA256"))
            mac.update(prev)
            mac.update(info)
            mac.update(counter.toByte())
            prev = mac.doFinal()
            val take = minOf(prev.size, outLen - pos)
            prev.copyInto(okm, pos, 0, take)
            pos += take
            counter++
            require(counter <= 255) { "HKDF output too long" }
        }
        prev.fill(0)
        return okm
    }

    /** Best-effort zeroization of sensitive byte arrays. */
    fun zeroize(vararg arrays: ByteArray) {
        arrays.forEach { it.fill(0) }
    }
}
