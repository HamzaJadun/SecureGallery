package com.hamza.securegallery.auth

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.hamza.securegallery.data.SecurePreferences
import com.hamza.securegallery.security.CryptoManager
import com.hamza.securegallery.security.KeyManager
import javax.crypto.Cipher

/**
 * Biometric unlock using a BiometricPrompt-bound CryptoObject.
 *
 * Flow:
 * - Enroll: user is unlocked via PIN → KeyManager.createBioWrapKey() →
 *   BiometricPrompt with ENCRYPT_MODE CryptoObject → wrap DEK → store blob.
 * - Unlock: BiometricPrompt with DECRYPT_MODE CryptoObject over the stored blob →
 *   on success, AuthManager.unlockWithDek().
 *
 * Biometric is strictly an *alternative* unlock the user opts into. It never
 * bypasses the PIN: disabling it deletes the bio key, and the PIN path always
 * remains. Failed biometric attempts are handled by the platform (lockout).
 */
class BiometricGate(
    private val context: Context,
    private val keys: KeyManager,
    private val crypto: CryptoManager,
    private val prefs: SecurePreferences,
    private val auth: AuthManager
) {

    fun canUse(): Boolean =
        keys.hasStrongBiometric(context) && auth.isBiometricEnabled

    fun isAvailableForEnrollment(): Boolean =
        keys.hasStrongBiometric(context) && auth.isUnlocked && !auth.isBiometricEnabled

    private fun promptInfo(enroll: Boolean): BiometricPrompt.PromptInfo =
        BiometricPrompt.PromptInfo.Builder()
            .setTitle(if (enroll) "Enable biometric unlock" else "Unlock SecureGallery")
            .setSubtitle(
                if (enroll) "Your fingerprint or face will unlock the vault on this device only."
                else "Authenticate to decrypt your private gallery."
            )
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .setNegativeButtonText("Use PIN instead")
            .build()

    private fun prompt(
        activity: FragmentActivity,
        info: BiometricPrompt.PromptInfo,
        onError: (String) -> Unit,
        onSuccess: (BiometricPrompt.AuthenticationResult) -> Unit
    ): BiometricPrompt {
        val executor = ContextCompat.getMainExecutor(context)
        return BiometricPrompt(
            activity, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationError(code: Int, msg: CharSequence) {
                    onError(msg.toString())
                }
                override fun onAuthenticationFailed() {
                    onError("Biometric not recognized, try again.")
                }
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onSuccess(result)
                }
            }
        ).also { /* promptInfo passed at authenticate() time */ }
    }

    /** Enrollment — call only while unlocked via PIN and after explicit user opt-in. */
    fun enroll(
        activity: FragmentActivity,
        onDone: (ok: Boolean, message: String) -> Unit
    ) {
        val dek = auth.sessionDek()
        if (dek == null) {
            onDone(false, "Unlock with your PIN first.")
            return
        }
        keys.createBioWrapKey()
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(
                Cipher.ENCRYPT_MODE,
                // Fetch the freshly created bio key via a wrap round-trip helper:
                // we init here directly to bind the CryptoObject.
                getBioKeyForCrypto()
            )
            val bp = prompt(
                activity, promptInfo(true),
                onError = { msg ->
                    keys.deleteBioWrapKey()
                    onDone(false, msg)
                },
                onSuccess = { result ->
                    val c = result.cryptoObject?.cipher
                    if (c == null) {
                        keys.deleteBioWrapKey()
                        onDone(false, "Crypto object missing — enrollment aborted.")
                        return@prompt
                    }
                    try {
                        val wrapped = keys.wrapWithBioKey(c, dek)
                        auth.enrollBiometric(wrapped)
                        crypto.zeroize(wrapped)
                        onDone(true, "Biometric unlock enabled.")
                    } catch (t: Throwable) {
                        keys.deleteBioWrapKey()
                        onDone(false, "Enrollment failed: ${t.message}")
                    }
                }
            )
            bp.authenticate(promptInfo(true), BiometricPrompt.CryptoObject(cipher))
        } catch (t: Throwable) {
            keys.deleteBioWrapKey()
            onDone(false, "Enrollment failed: ${t.message}")
        }
    }

    /** Unlock — unwraps the bio-gated DEK copy and establishes the session. */
    fun unlock(
        activity: FragmentActivity,
        onDone: (ok: Boolean, message: String) -> Unit
    ) {
        val wrapped = prefs.getBlob(SecurePreferences.Keys.WRAPPED_DEK_BIO)
        if (wrapped == null) {
            onDone(false, "Biometric unlock is not enrolled.")
            return
        }
        try {
            val (cipher, ct) = keys.bioDecryptCipher(wrapped)
            val bp = prompt(
                activity, promptInfo(false),
                onError = { msg -> onDone(false, msg) },
                onSuccess = { result ->
                    val c = result.cryptoObject?.cipher
                    if (c == null) {
                        onDone(false, "Crypto object missing — unlock aborted.")
                        return@prompt
                    }
                    try {
                        val dek = c.doFinal(ct)
                        auth.unlockWithDek(dek)
                        crypto.zeroize(dek)
                        onDone(true, "Unlocked.")
                    } catch (t: Throwable) {
                        onDone(false, "Decryption failed — vault may be corrupted.")
                    }
                }
            )
            bp.authenticate(promptInfo(false), BiometricPrompt.CryptoObject(cipher))
        } catch (t: Throwable) {
            onDone(false, "Biometric unlock unavailable: ${t.message}")
        }
    }

    /** Reaches into the Keystore for the bio key (encrypt-mode init needs the key). */
    private fun getBioKeyForCrypto(): javax.crypto.SecretKey {
        val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        return ks.getKey(KeyManager.BIO_ALIAS, null) as javax.crypto.SecretKey
    }
}
