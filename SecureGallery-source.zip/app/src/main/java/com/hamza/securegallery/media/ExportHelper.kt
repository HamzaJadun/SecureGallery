package com.hamza.securegallery.media

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.hamza.securegallery.data.MediaItem
import com.hamza.securegallery.data.VaultRepository
import com.hamza.securegallery.security.CryptoManager
import com.hamza.securegallery.security.SecureWipe
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/**
 * Explicit, user-consented export only.
 *
 * - Decrypts ONE item into getCacheDir()/export/<random>.tmp (never the
 *   original filename, never a public directory).
 * - Shares via FileProvider with FLAG_GRANT_READ_URI_PERMISSION — a one-shot
 *   grant to the chosen target app, not a world-readable file.
 * - [cleanup] overwrites + deletes the temp file. Callers must invoke it when
 *   the share returns AND in onDestroy as a safety net.
 * - There is no "share" affordance anywhere else in the app; the viewer has
 *   no share/print/cast buttons by design.
 */
class ExportHelper(
    private val context: Context,
    private val repo: VaultRepository,
    private val crypto: CryptoManager
) {
    private val exportDir: File
        get() = File(context.cacheDir, "export").apply { mkdirs() }

    /** Decrypts [item] to a temp file and returns a one-shot content URI. */
    fun prepareExport(item: MediaItem, dek: ByteArray): android.net.Uri {
        cleanup() // never leave a previous export behind
        val tmp = File(exportDir, "${UUID.randomUUID()}.tmp")
        repo.fileFor(item.vaultName).inputStream().use { fis ->
            FileOutputStream(tmp).use { out ->
                crypto.decryptStream(dek, fis, out)
            }
        }
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.exportprovider",
            tmp
        )
    }

    fun shareIntent(uri: android.net.Uri, mime: String): Intent =
        Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT)
        }

    /** Overwrite + delete all temp exports. Safe to call any time. */
    fun cleanup() {
        try {
            exportDir.listFiles()?.forEach { SecureWipe.wipeFile(it) }
        } catch (_: Exception) { }
    }
}
