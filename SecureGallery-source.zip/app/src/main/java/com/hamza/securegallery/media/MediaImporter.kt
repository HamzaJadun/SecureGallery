package com.hamza.securegallery.media

import android.content.Context
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import com.hamza.securegallery.data.MediaItem
import com.hamza.securegallery.data.VaultRepository
import com.hamza.securegallery.security.CryptoManager
import com.hamza.securegallery.security.SecureWipe
import java.io.File
import java.io.FileOutputStream
import java.io.SequenceInputStream
import java.util.UUID

/**
 * Imports media through the system Photo Picker into the encrypted vault.
 *
 * Security properties:
 * - No storage permission requested; the picker grants a one-shot read URI.
 * - MIME allowlist + magic-byte sniffing: the declared type must match the
 *   actual bytes. Polyglots / disguised executables are rejected.
 * - Destination names are random UUIDs — the original filename never touches
 *   the filesystem (kills path traversal).
 * - Streaming encryption: source bytes are never fully buffered in RAM and no
 *   plaintext temp file is ever written.
 * - 4 GB per-file cap enforced during the copy (aborts + wipes partial file).
 * - On any failure the partial ciphertext is wiped and no DB row is written.
 */
class MediaImporter(
    private val context: Context,
    private val repo: VaultRepository,
    private val crypto: CryptoManager
) {
    data class ImportResult(val imported: Int, val skipped: List<String>)

    companion object {
        const val MAX_BYTES = 4L * 1024 * 1024 * 1024 // 4 GB

        private val ALLOWED_MIME = setOf(
            "image/jpeg", "image/png", "image/webp", "image/heif", "image/heic",
            "video/mp4", "video/quicktime", "video/3gpp", "video/3gpp2",
            "video/webm", "video/x-matroska"
        )

        /** (magic prefix, allowed mime set) — checked in order. */
        private val MAGIC: List<Pair<ByteArray, Set<String>>> = listOf(
            hex("FFD8FF") to setOf("image/jpeg"),
            hex("89504E470D0A1A0A") to setOf("image/png"),
            hex("1A45DFA3") to setOf("video/webm", "video/x-matroska"),
        )

        private fun hex(s: String): ByteArray =
            s.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
    }

    fun importUris(uris: List<Uri>, albumId: String, dek: ByteArray): ImportResult {
        var ok = 0
        val skipped = mutableListOf<String>()
        for (uri in uris) {
            try {
                importOne(uri, albumId, dek)
                ok++
            } catch (t: Throwable) {
                skipped += "${displayName(uri)} (${t.message ?: "rejected"})"
            }
        }
        return ImportResult(ok, skipped)
    }

    private fun importOne(uri: Uri, albumId: String, dek: ByteArray) {
        val cr = context.contentResolver
        val declared = cr.getType(uri)
        if (declared != null && declared !in ALLOWED_MIME) {
            throw IllegalArgumentException("type not allowed: $declared")
        }

        val raw = cr.openInputStream(uri) ?: throw IllegalArgumentException("cannot open")
        raw.use { src ->
            // Peek magic bytes, then replay them via SequenceInputStream.
            val head = ByteArray(16)
            var n = 0
            while (n < head.size) {
                val r = src.read(head, n, head.size - n)
                if (r < 0) break
                n += r
            }
            if (n < 4) throw IllegalArgumentException("empty file")
            val sniffed = sniff(head, n)
                ?: throw IllegalArgumentException("unrecognized file signature")
            if (declared != null && declared !in sniffed) {
                throw IllegalArgumentException("declared type doesn't match file content")
            }
            val mime = declared ?: sniffed.first()

            val id = UUID.randomUUID().toString()
            val vaultName = "$id.enc"
            val dest = repo.fileFor(vaultName)
            var bytesWritten = 0L
            try {
                val replay = SequenceInputStream(
                    java.io.ByteArrayInputStream(head, 0, n), src
                )
                replay.use { r ->
                    val counted = CountingInputStream(r) { total ->
                        if (total > MAX_BYTES) throw IllegalArgumentException("file too large")
                    }
                    FileOutputStream(dest).use { out ->
                        // Counted copy with cap; then encrypt through it.
                        crypto.encryptStream(dek, counted, out)
                        bytesWritten = counted.total
                    }
                }
                if (bytesWritten <= 16) throw IllegalArgumentException("empty file")

                val (w, h) = if (mime.startsWith("image/")) imageDims(dest, dek) else null to null
                val duration = if (mime.startsWith("video/")) videoDuration(uri) else null

                repo.insertMedia(
                    MediaItem(
                        id = id, albumId = albumId, vaultName = vaultName,
                        origName = displayName(uri).take(120), mime = mime,
                        sizeBytes = bytesWritten, width = w, height = h,
                        durationMs = duration, addedAt = System.currentTimeMillis(),
                        starred = false
                    )
                )
            } catch (t: Throwable) {
                SecureWipe.wipeFile(dest)
                throw t
            }
        }
        // Release the one-shot URI grant.
        try { cr.releasePersistableUriPermission(uri, 0) } catch (_: Exception) { }
    }

    private fun sniff(head: ByteArray, n: Int): Set<String>? {
        for ((magic, mimes) in MAGIC) {
            if (n >= magic.size && head.copyOf(magic.size).contentEquals(magic)) return mimes
        }
        // RIFF....WEBP
        if (n >= 12 && head[0] == 0x52.toByte() && head[1] == 0x49.toByte() &&
            head[2] == 0x46.toByte() && head[3] == 0x46.toByte() &&
            head[8] == 0x57.toByte() && head[9] == 0x45.toByte() &&
            head[10] == 0x42.toByte() && head[11] == 0x50.toByte()
        ) return setOf("image/webp")
        // ....ftyp....  (mp4 / mov / heic / 3gp)
        if (n >= 12 && head[4] == 0x66.toByte() && head[5] == 0x74.toByte() &&
            head[6] == 0x79.toByte() && head[7] == 0x70.toByte()
        ) {
            val brand = String(head, 8, minOf(4, n - 8))
            return when {
                brand.startsWith("heic") || brand.startsWith("heix") ||
                    brand.startsWith("mif1") -> setOf("image/heif", "image/heic")
                brand.startsWith("qt") -> setOf("video/quicktime")
                brand.startsWith("3gp") -> setOf("video/3gpp", "video/3gpp2")
                else -> setOf("video/mp4")
            }
        }
        return null
    }

    private fun displayName(uri: Uri): String {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            .use { c ->
                if (c != null && c.moveToFirst()) {
                    return c.getString(0) ?: "unknown"
                }
            }
        return uri.lastPathSegment ?: "unknown"
    }

    /** Decodes only bounds from the *decrypted* bytes — never writes plaintext. */
    private fun imageDims(encFile: File, dek: ByteArray): Pair<Int?, Int?> {
        return try {
            // Bound the in-memory read: dims live in the first bytes of most formats.
            // We decrypt just enough via a capped stream.
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            encFile.inputStream().use { fis ->
                val capped = CappedDecryptStream(fis, dek, crypto, 4 * 1024 * 1024)
                BitmapFactory.decodeStream(capped, null, opts)
            }
            if (opts.outWidth > 0) opts.outWidth to opts.outHeight else null to null
        } catch (_: Exception) {
            null to null
        }
    }

    private fun videoDuration(uri: Uri): Long? {
        return try {
            MediaMetadataRetriever().use { r ->
                r.setDataSource(context, uri)
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            }
        } catch (_: Exception) {
            null
        }
    }

    /** Counts bytes passing through; aborts via [onCount] when the cap is exceeded. */
    private class CountingInputStream(
        private val inner: java.io.InputStream,
        private val onCount: (Long) -> Unit
    ) : java.io.InputStream() {
        var total = 0L
        override fun read(): Int {
            val b = inner.read()
            if (b >= 0) { total++; onCount(total) }
            return b
        }
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val r = inner.read(b, off, len)
            if (r > 0) { total += r; onCount(total) }
            return r
        }
        override fun close() = inner.close()
    }

    /**
     * Decrypts at most [cap] bytes for metadata probing. The GCM tag check will
     * fail on truncation — that's fine here, we only want header dims.
     */
    private class CappedDecryptStream(
        src: java.io.InputStream,
        dek: ByteArray,
        crypto: CryptoManager,
        cap: Int
    ) : java.io.InputStream() {
        private val buf: ByteArray
        private var pos = 0
        init {
            val tmp = java.io.ByteArrayOutputStream()
            val capped = object : java.io.FilterInputStream(src) {
                var left = cap.toLong()
                override fun read(b: ByteArray, off: Int, len: Int): Int {
                    if (left <= 0) return -1
                    val r = super.read(b, off, minOf(len, left.toInt()))
                    if (r > 0) left -= r
                    return r
                }
            }
            try {
                crypto.decryptStream(dek, capped, tmp)
            } catch (_: Exception) { /* truncated tag — header bytes still useful */ }
            buf = tmp.toByteArray()
        }
        override fun read(): Int = if (pos < buf.size) buf[pos++].toInt() and 0xFF else -1
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (pos >= buf.size) return -1
            val r = minOf(len, buf.size - pos)
            buf.copyInto(b, off, pos, pos + r); pos += r
            return r
        }
    }
}
