package com.hamza.securegallery

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Environment
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Static security assertions about the installed app. These run on a device/
 * emulator and fail the build if the hardening regresses.
 */
@RunWith(AndroidJUnit4::class)
class ManifestSecurityTest {

    private val context get() = InstrumentationRegistry.getInstrumentation().targetContext
    private val pm get() = context.packageManager

    @Test fun `backups are disabled`() {
        val ai = pm.getApplicationInfo(context.packageName, 0)
        assertEquals(
            "allowBackup must be false",
            0, ai.flags and ApplicationInfo.FLAG_ALLOW_BACKUP
        )
    }

    @Test fun `only the launcher activity is exported`() {
        val pkg = pm.getPackageInfo(
            context.packageName,
            PackageManager.GET_ACTIVITIES or PackageManager.GET_SERVICES or
                PackageManager.GET_RECEIVERS or PackageManager.GET_PROVIDERS
        )
        val exported = mutableListOf<String>()
        pkg.activities?.forEach { if (it.exported) exported += "activity:${it.name}" }
        pkg.services?.forEach { if (it.exported) exported += "service:${it.name}" }
        pkg.receivers?.forEach { if (it.exported) exported += "receiver:${it.name}" }
        pkg.providers?.forEach { if (it.exported) exported += "provider:${it.name}" }
        assertEquals(
            "Only MainActivity may be exported, found: $exported",
            listOf("activity:com.hamza.securegallery.ui.MainActivity"),
            exported.sorted()
        )
    }

    @Test fun `no storage or network permissions requested`() {
        val pkg = pm.getPackageInfo(context.packageName, PackageManager.GET_PERMISSIONS)
        val requested = pkg.requestedPermissions?.toList() ?: emptyList()
        val dangerous = requested.filter {
            it.contains("STORAGE") || it.contains("MEDIA") || it.contains("INTERNET") ||
                it.contains("CAMERA") || it.contains("LOCATION")
        }
        assertTrue("Unexpected permissions: $dangerous", dangerous.isEmpty())
    }
}
