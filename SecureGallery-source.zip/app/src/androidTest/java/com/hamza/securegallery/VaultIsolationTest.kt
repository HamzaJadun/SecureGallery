package com.hamza.securegallery

import android.content.ContentUris
import android.provider.MediaStore
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.hamza.securegallery.data.MediaItem
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.UUID

/**
 * End-to-end vault isolation: enroll → unlock → import a fake image into the
 * vault → prove (a) the bytes on disk are ciphertext, (b) MediaStore has no
 * record of the file, (c) locking closes the DB and drops the session.
 *
 * Requires a device/emulator (Android Keystore + SQLCipher are native).
 */
@RunWith(AndroidJUnit4::class)
class VaultIsolationTest {

    private val app: SecureGalleryApp
        get() = InstrumentationRegistry.getInstrumentation()
            .targetContext.applicationContext as SecureGalleryApp

    @Test fun `vault round trip keeps plaintext off disk and out of mediastore`() {
        val a = app
        val pin = "123456".toCharArray()
        try {
            a.authManager.enroll(pin)
            val dek = a.authManager.sessionDek()!!
            a.openVault(dek)

            // Fake a minimal PNG (magic bytes + filler) and encrypt it as an import would.
            val fakePng = byteArrayOf(
                0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A
            ) + ByteArray(1024) { 0x42 }
            val id = UUID.randomUUID().toString()
            val vaultName = "$id.enc"
            val dest = a.repo.fileFor(vaultName)
            dest.outputStream().use { out ->
                a.crypto.encryptStream(dek, ByteArrayInputStream(fakePng), out)
            }
            a.repo.insertMedia(
                MediaItem(
                    id, "default", vaultName, "test.png", "image/png",
                    fakePng.size.toLong(), null, null, null,
                    System.currentTimeMillis(), false
                )
            )

            // (a) bytes on disk are NOT the plaintext (ciphertext, nonce-prefixed)
            val onDisk = dest.readBytes()
            assertTrue(onDisk.size > 12)
            val head = onDisk.copyOfRange(12, 20)
            assertFalse(
                "vault file must not contain plaintext",
                head.contentEquals(fakePng.copyOfRange(0, 8))
            )

            // (b) MediaStore knows nothing about it
            val cr = a.contentResolver
            cr.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Images.Media._ID),
                "${MediaStore.Images.Media.DISPLAY_NAME}=?",
                arrayOf("test.png"), null
            ).use { c ->
                assertTrue("MediaStore must have no record", c == null || c.count == 0)
            }

            // (c) decrypt round-trips while unlocked
            val plain = ByteArrayOutputStream()
            dest.inputStream().use { fis -> a.crypto.decryptStream(dek, fis, plain) }
            assertArrayEquals(fakePng, plain.toByteArray())

            // (d) lock drops everything
            a.lockNow("test")
            assertFalse(a.authManager.isUnlocked)
            assertFalse(a.repo.isOpen())
            assertNull(a.authManager.sessionDek())
        } finally {
            // Leave no test vault behind.
            try { a.authManager.wipeVault() } catch (_: Exception) { }
        }
    }

    @Test fun `vault lives under private internal storage`() {
        val a = app
        val vaultDir = java.io.File(a.filesDir, "vault")
        assertTrue(
            vaultDir.absolutePath.startsWith(a.filesDir.absolutePath),
            "vault must be inside app-private filesDir"
        )
        assertFalse(
            vaultDir.absolutePath.contains("DCIM") ||
                vaultDir.absolutePath.contains("Pictures"),
            "vault must never be under public media dirs"
        )
    }
}
