# Keep SQLCipher native init and our crypto entry points; everything else may shrink.
-keep class net.sqlcipher.** { *; }
-keep class net.sqlcipher.database.** { *; }
-keep class com.hamza.securegallery.security.** { *; }
-keep class com.hamza.securegallery.auth.** { *; }
# Biometric + security-crypto use reflection internally.
-keep class androidx.biometric.** { *; }
-keep class androidx.security.crypto.** { *; }
# Compose / Material3
-keep class androidx.compose.** { *; }
-dontwarn net.sqlcipher.**
