# SecureGallery — Security Testing Plan

Run top-down: automated tests first, then manual verification, then static
analysis. Record results in the table at the end. Anything marked FAIL blocks
release.

## A. Automated tests (in repo)

### A1 — Host unit tests (`./gradlew testDebugUnitTest`)
| Test | Verifies |
|---|---|
| `CryptoManagerTest` round trip (bytes + 300 KB stream) | AES-GCM streaming correctness |
| `tampered ciphertext fails closed` / `tampered nonce` / `wrong key` | T12 — any modification → `AEADBadTagException`, never silent corruption |
| `same plaintext → different ciphertext` | Random 96-bit nonce per file (no nonce reuse) |
| `truncated file is rejected` | Short reads fail instead of producing partial plaintext |
| `hkdf deterministic + domain-separated` | DB passphrase derivation is stable and distinct per `info` |
| `AuthRateLimitTest` backoff 1s→2s→4s… cap 5 min | T10 — exponential backoff schedule |
| `SecureWipeTest` | Overwrite-then-delete; missing file doesn't throw |

### A2 — Instrumented tests (`./gradlew connectedDebugAndroidTest`, device needed)
| Test | Verifies |
|---|---|
| `ManifestSecurityTest.backups are disabled` | T6 — `FLAG_ALLOW_BACKUP == 0` |
| `only the launcher activity is exported` | T9 — no exported services/receivers/providers |
| `no storage or network permissions requested` | Least privilege (§3) |
| `VaultIsolationTest` round trip | T1/T2/T3 — disk bytes are ciphertext; MediaStore has no record; lock drops DEK + closes DB |
| `vault lives under private internal storage` | §2 — never under DCIM/Pictures/Downloads |

## B. Manual verification (checklist)

**B1 — Cross-app isolation (T1, T2)**
1. Import 3 photos + 1 video. Lock the vault.
2. Open a file manager (e.g. Files by Google) → browse
   `Android/data/com.hamza.securegallery/files/vault/media/` — confirm access
   is denied (other apps cannot list another app's private dir on API 29+).
3. `adb shell run-as com.hamza.securegallery ls files/vault/media` (debuggable
   builds only) → files present, all `*.enc`.
4. Copy one `.enc` to a PC → confirm it's random-looking bytes, unopenable.

**B2 — Public-surface absence (T3)**
1. Open the system Gallery / Google Photos → vault items must NOT appear.
2. `adb shell content query --uri content://media/external/images/media` →
   no rows referencing the vault.

**B3 — Screenshots & Recents (T4, T11)**
1. Open Viewer → try screenshot → expect black image / "couldn't capture" toast.
2. Open Recents with vault unlocked → app card must show black, not content.
3. Background the app → foreground → must show LockScreen (immediate default).

**B4 — Auth robustness (T5, T10)**
1. Enter wrong PIN 3× → waits of 1s, 2s, 4s enforced; input disabled during wait.
2. Kill the process mid-backoff → relaunch → counters persisted, backoff continues.
3. Correct PIN after backoff → unlocks, counters reset.
4. Enable "wipe after 10 failures" on a THROWAWAY vault → 10 wrong PINs →
   vault wiped, app returns to onboarding.

**B5 — Tamper & corruption (T12)**
1. Debuggable build: flip one byte in a `.enc` file via `run-as` + `dd`.
2. Open the item → must show an error, never a garbled image.

**B6 — Import abuse (T8)**
1. Try importing: a renamed `.exe` → rejected ("unrecognized file signature").
2. A JPEG with mismatched declared type → rejected.
3. A path-traversal filename (`../../evil.png`) → stored as random UUID anyway.
4. A >4 GB file (or lower the cap temporarily) → aborted, partial file wiped.

**B7 — Backup leakage (T6)**
1. `adb backup -f test.ab com.hamza.securegallery` → must refuse/empty.
2. Fresh install → no vault data restored (by design: none was ever backed up).

**B8 — Export hygiene (§5)**
1. Export a photo → share to another app → return → `cache/export/` must be empty.
2. Force-stop mid-share → relaunch → export dir still empty (cleanup on lock + destroy).

**B9 — Lock paths (§4)**
1. Screen off while viewing → immediate lock.
2. Auto-lock 1 min → wait idle 1 min in gallery → locked.
3. Manual lock button → locked instantly; thumbnail grid shows nothing on return.

## C. Static analysis

1. **Android Lint**: `./gradlew lint` → zero `Security` warnings.
   (Allowlist any false positive with a comment explaining why.)
2. **MobSF** (Mobile Security Framework) on the release APK → review all
   HIGH findings; expected clean except informational `allowBackup` notes.
3. **Dependency check**: `./gradlew dependencyCheckAnalyze` (OWASP DC) or
   manual review of `libs.versions.toml` — SQLCipher, biometric, security-crypto
   on current stable.
4. **Manifest audit**: `aapt dump xmltree app.apk AndroidManifest.xml` →
   confirm `exported=false` everywhere except MainActivity, no permissions.

## D. Known residual risks (accepted, documented to the user)

| ID | Risk | Status |
|---|---|---|
| R-1 | Root / compromised OS can read Keystore keys + memory | Unfixable at app layer; disclosed in-app (Settings → Security status) |
| R-2 | Unlocked-device memory scraping (debugger/Frida) | Mitigated by auto-lock minimizing the window; disclosed |
| R-3 | SQLCipher passphrase passes through a short-lived `String` | Zeroized source bytes; heap copies GC'd; accepted |
| R-4 | Flash wear-leveling limits secure-delete guarantees | Overwrite-then-delete is best effort; disclosed |
| R-5 | GCM video seeking re-decrypts from offset 0 (perf, not security) | Accepted; alternative (CTR+HMAC seekable) loses single-pass AEAD |
| R-6 | No video frame thumbnails (would need plaintext temp) | Deliberate tradeoff, documented in code |

## E. Results log

| Date | Build | Tester | A1 | A2 | B1–B9 | C | Notes |
|---|---|---|---|---|---|---|---|
| _ | _ | _ | _ | _ | _ | _ | _Fill after first device run_ |
